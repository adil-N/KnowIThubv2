require('dotenv').config(); // Load environment variables
const mongoose = require('mongoose'); // Connect to MongoDB
const User = require('./models/User'); // Your User model
const bcrypt = require('bcryptjs'); // For password hashing

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log('MongoDB connected');
        createInitialUsers(); // Call to create admin users after successful connection
    })
    .catch(err => {
        console.error('MongoDB connection error:', err);
        process.exit(1);
    });

async function createAdmin(email, password, firstName, lastName, role) {
    const hashedPassword = await bcrypt.hash(password, 10);
    return User.create({
        email,
        password: hashedPassword,
        firstName,
        lastName,
        role,
        status: 'active'
    });
}

async function createInitialUsers() {
    try {
        // Check if super admin exists
        const superAdminExists = await User.findOne({ role: 'super' });
        if (!superAdminExists) {
            await createAdmin(process.env.INITIAL_ADMIN_EMAIL, process.env.INITIAL_ADMIN_PASSWORD, 'Super', 'Admin', 'super');
            console.log('Initial super admin created');
        } else {
            console.log('Super admin already exists');
        }

        // Check if regular admin exists
        const adminExists = await User.findOne({ role: 'admin' });
        if (!adminExists) {
            await createAdmin(process.env.REGULAR_ADMIN_EMAIL, process.env.REGULAR_ADMIN_PASSWORD, 'Regular', 'Admin', 'admin');
            console.log('Initial regular admin created');
        } else {
            console.log('Regular admin already exists');
        }

        process.exit(0);
    } catch (error) {
        console.error('Setup failed:', error);
        process.exit(1);
    }
}
