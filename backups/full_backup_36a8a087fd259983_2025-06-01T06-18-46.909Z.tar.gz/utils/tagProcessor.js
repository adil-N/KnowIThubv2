// utils/tagProcessor.js
const natural = require('natural');
const stopwords = require('stopwords').english;
const cheerio = require('cheerio');

class TagProcessor {
    constructor() {
        // Initialize tokenizer
        this.tokenizer = new natural.WordTokenizer();
        
        // Configuration constants
        this.MIN_WORD_LENGTH = 3;
        this.MAX_WORD_LENGTH = 30;
        this.MIN_FREQUENCY = 1;
        this.MAX_TAGS = 10;

        // Initialize blacklist with focused terms
        this.blacklist = new Set([
            ...stopwords,
            // Common HTML terms only
            'div', 'span', 'class', 'href', 'src', 'img', 'alt', 'width', 'height',
            // Basic technical terms
            'null', 'undefined', 'nan','pos','concouse','ddf',
            // Common test terms
            'example', 'sample', 'demo', 'todo', 'test', 'fix', 'bug', 'error', 'issue', 'problem', 'solution', 'tag', 'tags',
            // Common words to exclude
            'the', 'and', 'or', 'but', 'for', 'yet', 'so','file','text',
            // Numbers written as words
            'one', 'two', 'three', 'first', 'second', 'third','gray','red',
            // Days of the week
            'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
            // Months of the year
            'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'
        ]);
        

        console.log('TagProcessor initialized with blacklist size:', this.blacklist.size);
    }

    async extractTags(title = '', content = '') {
        try {
            console.log('\n=== Starting Tag Extraction ===');
            console.log('Processing text length - Title:', title.length, 'Content:', content.length);

            // Clean content first
            const cleanContent = this.cleanContent(content);
            console.log('Content cleaned, new length:', cleanContent.length);

            // Tokenize text
            const titleWords = this.tokenizer.tokenize(title.toLowerCase()) || [];
            const contentWords = this.tokenizer.tokenize(cleanContent.toLowerCase()) || [];

            console.log('Word counts - Title:', titleWords.length, 'Content:', contentWords.length);

            // Build frequency map with weights
            const wordFreq = new Map();

            // Process title words (weight: 3)
            titleWords.forEach(word => {
                if (this.isValidWord(word)) {
                    const normalized = word.toLowerCase().trim();
                    wordFreq.set(normalized, (wordFreq.get(normalized) || 0) + 3);
                }
            });

            // Process content words (weight: 1)
            contentWords.forEach(word => {
                if (this.isValidWord(word)) {
                    const normalized = word.toLowerCase().trim();
                    wordFreq.set(normalized, (wordFreq.get(normalized) || 0) + 1);
                }
            });

            // Process phrases (weight: 2)
            const phrases = this.extractPhrases(cleanContent);
            phrases.forEach(phrase => {
                if (this.isValidPhrase(phrase)) {
                    wordFreq.set(phrase, (wordFreq.get(phrase) || 0) + 2);
                }
            });

            // Log frequency data
            console.log('Word frequency map size:', wordFreq.size);
            
            // Get final tags
            const finalTags = Array.from(wordFreq.entries())
                .filter(([word, freq]) => {
                    // Log rejected words for debugging
                    if (freq < this.MIN_FREQUENCY) {
                        console.log(`Rejected '${word}': low frequency (${freq})`);
                        return false;
                    }
                    if (this.blacklist.has(word)) {
                        console.log(`Rejected '${word}': blacklisted`);
                        return false;
                    }
                    return true;
                })
                .sort((a, b) => b[1] - a[1])
                .slice(0, this.MAX_TAGS)
                .map(([word]) => word);

            console.log('Final tags generated:', finalTags);
            return finalTags;

        } catch (error) {
            console.error('Error in extractTags:', error);
            return [];
        }
    }

    isValidWord(word) {
        if (!word) return false;

        const normalized = word.toLowerCase().trim();
        
        // Basic validation criteria
        const validLength = normalized.length >= this.MIN_WORD_LENGTH && 
                          normalized.length <= this.MAX_WORD_LENGTH;
        const notBlacklisted = !this.blacklist.has(normalized);
        const validCharacters = /^[a-z0-9-]+$/i.test(normalized);
        const noRepeatingChars = !/(.)\1{2,}/.test(normalized);
        
        // Log validation results for debugging
        if (!validLength) console.log(`Word '${normalized}' rejected: invalid length`);
        if (!notBlacklisted) console.log(`Word '${normalized}' rejected: blacklisted`);
        if (!validCharacters) console.log(`Word '${normalized}' rejected: invalid characters`);
        if (!noRepeatingChars) console.log(`Word '${normalized}' rejected: repeating characters`);

        return validLength && notBlacklisted && validCharacters && noRepeatingChars;
    }

    isValidPhrase(phrase) {
        if (!phrase || typeof phrase !== 'string') return false;

        const words = phrase.split(' ');
        const validWordCount = words.length === 2;
        const allWordsValid = words.every(word => this.isValidWord(word));
        const notBlacklisted = !this.blacklist.has(phrase.toLowerCase());

        // Log validation results
        if (!validWordCount) console.log(`Phrase '${phrase}' rejected: invalid word count`);
        if (!allWordsValid) console.log(`Phrase '${phrase}' rejected: invalid words`);
        if (!notBlacklisted) console.log(`Phrase '${phrase}' rejected: blacklisted`);

        return validWordCount && allWordsValid && notBlacklisted;
    }

    extractPhrases(text) {
        if (!text) return [];

        const words = text.toLowerCase().split(/\s+/);
        const phrases = [];
        
        for (let i = 0; i < words.length - 1; i++) {
            const phrase = `${words[i]} ${words[i + 1]}`;
            if (this.isValidPhrase(phrase)) {
                phrases.push(phrase);
            }
        }
        
        console.log(`Extracted ${phrases.length} valid phrases`);
        return phrases;
    }

    cleanContent(content) {
        try {
            if (!content) return '';
            
            // Load content into cheerio
            const $ = cheerio.load(content);

            // Remove unwanted elements
            $('script, style, noscript, iframe, embed, object, video, audio').remove();
            $('img[src^="data:"], [style*="base64"]').remove();
            
            // Get text content
            let text = $.text();

            // Clean up text
            text = text
                .replace(/\s+/g, ' ')               // Normalize whitespace
                .replace(/[^\w\s-]/g, ' ')          // Keep only words, spaces, and hyphens
                .replace(/\b\d+\b/g, '')            // Remove standalone numbers
                .replace(/\b[a-z]\b/gi, '')         // Remove single-letter words
                .trim();

            console.log('Content cleaned successfully');
            return text;

        } catch (error) {
            console.error('Error cleaning content:', error);
            // Fallback cleaning method
            return content
                .replace(/<[^>]+>/g, ' ')
                .replace(/\s+/g, ' ')
                .trim();
        }
    }

    filterRedundantTags(autoTags, manualTags) {
        console.log('Starting tag filtering process:', {
            autoTagsCount: autoTags.length,
            manualTagsCount: manualTags.length
        });

        const manualTagSet = new Set(manualTags.map(tag => tag.toLowerCase()));
        
        const filteredTags = autoTags.filter(autoTag => {
            const normalized = autoTag.toLowerCase();
            
            // Skip if exact match with manual tag
            if (manualTagSet.has(normalized)) {
                console.log(`Filtered out '${normalized}': exact match with manual tag`);
                return false;
            }

            // Skip if blacklisted
            if (this.blacklist.has(normalized)) {
                console.log(`Filtered out '${normalized}': blacklisted`);
                return false;
            }

            // Check for similar tags
            for (const manualTag of manualTagSet) {
                if (manualTag.includes(normalized) || normalized.includes(manualTag)) {
                    console.log(`Filtered out '${normalized}': similar to manual tag '${manualTag}'`);
                    return false;
                }
            }

            return true;
        });

        console.log('Tag filtering complete:', {
            originalCount: autoTags.length,
            remainingCount: filteredTags.length,
            filteredOut: autoTags.length - filteredTags.length
        });

        return filteredTags;
    }
}

module.exports = TagProcessor;