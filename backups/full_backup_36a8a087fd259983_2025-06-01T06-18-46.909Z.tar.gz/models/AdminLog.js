// models/AdminLog.js
const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    adminId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    action: {
        type: String,
        required: true,
        enum: [
            'USER_LOGIN', 'USER_LOGOUT', 'USER_CREATED', 'USER_UPDATED',
            'USER_DELETED', 'USER_PASSWORD_RESET', 'USER_STATUS_CHANGED',
            'USER_ROLE_CHANGED', 'ARTICLE_CREATED', 'ARTICLE_UPDATED',
            'ARTICLE_DELETED', 'ARTICLE_VISIBILITY_CHANGED', 'COMMENT_ADDED',
            'COMMENT_DELETED', 'COMMENT_MODERATED', 'ADMIN_LOGIN', 'ADMIN_CREATED',
            'ADMIN_UPDATED', 'ADMIN_DELETED', 'ADMIN_PASSWORD_RESET',
            'SETTINGS_UPDATED', 'BACKUP_CREATED', 'SYSTEM_MAINTENANCE',
            'ERROR_OCCURRED'
        ]
    },
    details: {
        type: mongoose.Schema.Types.Mixed,
        default: {}
    },
    targetUser: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: false
    },
    targetArticle: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Article',
        required: false
    },
    timestamp: {
        type: Date,
        default: Date.now
    }
});

schema.statics.logActivity = async function(data) {
    try {
        const log = new this(data);
        await log.save();
        return log;
    } catch (error) {
        console.error('Error logging admin activity:', error);
        throw error;
    }
};

schema.statics.getRecentLogs = async function(limit = 20) {
    try {
        const logs = await this.find()
            .populate({
                path: 'targetArticle',
                model: 'Article',
                select: 'displayId articleNumber title author',
                populate: {
                    path: 'author',
                    model: 'User',
                    select: 'firstName lastName email'
                }
            })
            .populate('adminId', 'firstName lastName email role')
            .sort({ timestamp: -1 })
            .limit(limit)
            .lean();

        return logs.map(log => {
            let articleId = null;
            
            // For ARTICLE_UPDATED action
            if (log.action === 'ARTICLE_UPDATED') {
                // Use original article number from details
                if (log.details?.originalArticleNumber) {
                    articleId = `AN-${String(log.details.originalArticleNumber).padStart(5, '0')}`;
                } else if (log.targetArticle?.articleNumber) {
                    articleId = `AN-${String(log.targetArticle.articleNumber).padStart(5, '0')}`;
                }
            }
            // For all other actions
            else if (log.targetArticle?.articleNumber) {
                articleId = `AN-${String(log.targetArticle.articleNumber).padStart(5, '0')}`;
            } else if (log.details?.articleNumber) {
                articleId = `AN-${String(log.details.articleNumber).padStart(5, '0')}`;
            }

            // Clean any double AN- prefixes
            if (articleId) {
                articleId = articleId.replace(/AN-AN-/, 'AN-');
            }

            return {
                ...log,
                formattedArticleId: articleId
            };
        });
    } catch (error) {
        console.error('Error getting recent logs:', error);
        throw error;
    }
};

const AdminLog = mongoose.model('AdminLog', schema);
module.exports = AdminLog;