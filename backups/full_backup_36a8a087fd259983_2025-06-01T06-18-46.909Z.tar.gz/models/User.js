// models/User.js
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const userSchema = new mongoose.Schema({
    firstName: {
        type: String,
        required: [true, 'First name is required'],
        trim: true,
        minlength: [2, 'First name must be at least 2 characters'],
        maxlength: [30, 'First name cannot exceed 30 characters']
    },
    lastName: {
        type: String,
        required: [true, 'Last name is required'],
        trim: true,
        minlength: [2, 'Last name must be at least 2 characters'],
        maxlength: [30, 'Last name cannot exceed 30 characters']
    },
    email: {
        type: String,
        unique: true,
        required: [true, 'Email address is required'],
        trim: true,
        lowercase: true,
        validate: {
            validator: function(v) {
                return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(v);
            },
            message: props => `${props.value} is not a valid email address!`
        }
    },
    password: {
        type: String,
        required: [true, 'Password is required'],
        minlength: [8, 'Password must be at least 8 characters']
    },
    passwordResetRequired: {
        type: Boolean,
        default: false
    },
    role: {
        type: String,
        enum: {
            values: ['user', 'admin', 'super'],
            message: '{VALUE} is not a valid role'
        },
        default: 'user'
    },
    inviteCode: {
        type: String,
        required: function() {
            return !['admin', 'super'].includes(this.role); // Only required for regular users
        },
        validate: {
            validator: function(v) {
                // Skip validation if admin or super
                if (['admin', 'super'].includes(this.role)) {
                    return true;
                }
                return !!v && v.length > 0; // Must have value for regular users
            },
            message: 'Invite code is required for regular users'
        }
    },
    lastLogin: {
        type: Date,
        default: Date.now
    },
    status: {
        type: String,
        enum: ['active', 'inactive', 'suspended'],
        default: 'active'
    },
    loginAttempts: {
        type: Number,
        default: 0
    },
    lockUntil: {
        type: Date
    },
    profileCompleted: {
        type: Boolean,
        default: false
    },
    bookmarks: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Article'
    }]
},

{
    timestamps: true
});

// Pre-save middleware to hash password
userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    
    try {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
        next();
    } catch (error) {
        next(error);
    }
});

// Method to check password
// In models/User.js, update the comparePassword method

userSchema.methods.comparePassword = async function(candidatePassword) {
    try {
        // Detailed debug logging
        console.log('Password comparison debug:', {
            candidatePassword: candidatePassword ? '****' : 'undefined',
            hashedPasswordExists: !!this.password,
            candidateLength: candidatePassword?.length,
            hashedLength: this.password?.length,
            passwordLastModified: this.isModified('password')
        });

        // Ensure both values exist
        if (!candidatePassword || !this.password) {
            console.log('Missing password data for comparison');
            return false;
        }

        // Log hash format check
        console.log('Hashed password format check:', {
            startsWithDollar: this.password.startsWith('$'),
            containsRounds: this.password.includes('$2b$') || this.password.includes('$2a$'),
            totalParts: this.password.split('$').length
        });

        // Use bcrypt.compare with detailed logging
        const isMatch = await bcrypt.compare(candidatePassword, this.password);
        console.log('Password comparison final result:', {
            isMatch,
            timestamp: new Date().toISOString()
        });
        
        return isMatch;
    } catch (error) {
        console.error('Password comparison error details:', {
            error: error.message,
            stack: error.stack,
            bcryptVersion: bcrypt.version || 'unknown'
        });
        return false;
    }
};

// Method to generate auth token
userSchema.methods.generateAuthToken = function() {
    const token = jwt.sign(
        { 
            userId: this._id,
            email: this.email,
            role: this.role
        }, 
        process.env.JWT_SECRET || 'your_jwt_secret',
        { expiresIn: '24h' }
    );
    return token;
};

// Method to increment login attempts
userSchema.methods.incrementLoginAttempts = async function() {
    // If lock has expired, reset attempts and remove lock
    if (this.lockUntil && this.lockUntil < Date.now()) {
        this.loginAttempts = 1;
        this.lockUntil = null;
    } else {
        // Increment attempts
        this.loginAttempts += 1;
        
        // Lock account if attempts exceed 5
        if (this.loginAttempts >= 5 && !this.lockUntil) {
            this.lockUntil = Date.now() + (15 * 60 * 1000); // Lock for 15 minutes
        }
    }
    await this.save();
};

// Method to reset login attempts
userSchema.methods.resetLoginAttempts = async function() {
    this.loginAttempts = 0;
    this.lockUntil = null;
    this.lastLogin = Date.now();
    await this.save();
};

// Add method to manage bookmarks
userSchema.methods.toggleBookmark = async function(articleId) {
    const index = this.bookmarks.indexOf(articleId);
    if (index > -1) {
        // Remove bookmark if already exists
        this.bookmarks.splice(index, 1);
    } else {
        // Add bookmark
        this.bookmarks.push(articleId);
    }
    await this.save();
    return this.bookmarks;
};
userSchema.methods.hasBookmarked = function(articleId) {
    return this.bookmarks.some(bookmark => 
        bookmark.toString() === articleId.toString()
    );
};

const User = mongoose.model('User', userSchema);

module.exports = User;