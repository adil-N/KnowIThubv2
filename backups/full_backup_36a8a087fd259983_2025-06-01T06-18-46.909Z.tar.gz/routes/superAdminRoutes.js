// routes/superAdminRoutes.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const superAdminController = require('../controllers/superAdminController');
const superAdminMiddleware = require('../middleware/superAdminAuth');

// Apply authentication and super admin middleware to all routes
router.use(auth);
router.use(superAdminMiddleware);

// Admin Management Routes
router.get('/admins', superAdminController.getAllAdmins);
router.get('/admins/:adminId', superAdminController.getAdmin);
router.post('/admins', superAdminController.createAdmin);
router.put('/admins/:adminId', superAdminController.updateAdmin);
router.delete('/admins/:adminId', superAdminController.deleteAdmin);
router.post('/admins/:adminId/reset-password', superAdminController.resetAdminPassword);

// System Settings Routes
router.get('/settings', superAdminController.getSettings);
router.post('/settings', superAdminController.updateSettings);

// Admin Logs Routes
router.get('/logs', superAdminController.getAdminLogs);
router.get('/logs/export', superAdminController.exportLogs);

module.exports = router;