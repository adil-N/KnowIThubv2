// routes/adminRoutes.js
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const articleController = require('../controllers/articleController');
const adminController = require('../controllers/adminController');
const User = require('../models/User');
const Article = require('../models/Article');
const Comment = require('../models/Comment');
const auth = require('../middleware/auth');
const { adminAuth } = require('../middleware/roleAuth');
const { roleAuth } = require('../middleware/roleAuth');
const AdminLog = require('../models/AdminLog');
const path = require('path');
const fs = require('fs').promises;
const { v4: uuidv4 } = require('uuid');


// Middleware to check admin role
const checkAdminRole = (req, res, next) => {
    console.log('Checking admin role:', {
        userRole: req.user?.role,
        hasAccess: req.user && ['admin', 'super'].includes(req.user.role)
    });

    if (!req.user || (req.user.role !== 'admin' && req.user.role !== 'super')) {
        return res.status(403).json({
            success: false,
            message: 'Access denied. Admin privileges required.'
        });
    }
    next();
};

// Middleware to check super admin role
const checkSuperAdminRole = (req, res, next) => {
    if (!req.user || req.user.role !== 'super') {
        return res.status(403).json({
            success: false,
            message: 'Access denied. Super admin privileges required.'
        });
    }
    next();
};

// Debug middleware
const debugMiddleware = (req, res, next) => {
    console.log('Admin route accessed:', {
        path: req.path,
        method: req.method,
        hasAuth: !!req.headers.authorization,
        user: req.user ? {
            id: req.user._id,
            role: req.user.role,
            email: req.user.email
        } : null
    });
    next();
};

// Apply middleware 
router.use(auth);
router.use(debugMiddleware);

// Stats route
router.get('/stats', checkAdminRole, async (req, res) => {
   try {
       // Get user stats
       const [totalUsers, activeUsers, inactiveUsers, adminUsers] = await Promise.all([
           User.countDocuments(),
           User.countDocuments({ status: 'active' }),
           User.countDocuments({ status: 'inactive' }),
           User.countDocuments({ role: 'admin' })
       ]);

       // Get content stats
       const [totalArticles, hiddenArticles, totalComments] = await Promise.all([
           Article.countDocuments(),
           Article.countDocuments({ hidden: true }), 
           Comment.countDocuments()
       ]);

       // Get latest activities
       const latestActivity = await AdminLog.find()
           .populate('adminId', 'email firstName lastName')
           .sort({ timestamp: -1 })
           .limit(10)
           .lean();

       // Get most active users
       const mostActiveUsers = await User.aggregate([
           {
               $lookup: {
                   from: 'articles',
                   localField: '_id',
                   foreignField: 'author',
                   as: 'articles'
               }
           },
           {
               $lookup: {
                   from: 'comments',
                   localField: '_id',
                   foreignField: 'author',
                   as: 'comments'
               }
           },
           {
               $addFields: {
                   articleCount: { $size: '$articles' },
                   commentCount: { $size: '$comments' },
                   lastWeekLogin: {
                       $cond: {
                           if: {
                               $gte: ['$lastLogin', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)]
                           },
                           then: 5,
                           else: 0
                       }
                   }
               }
           },
           {
               $addFields: {
                   activityScore: {
                       $add: [
                           { $multiply: ['$articleCount', 10] },
                           { $multiply: ['$commentCount', 2] },
                           '$lastWeekLogin'
                       ]
                   }
               }
           },
           {
               $project: {
                   email: 1,
                   firstName: 1,
                   lastName: 1,
                   articleCount: 1,
                   commentCount: 1,
                   lastLogin: 1,
                   activityScore: 1
               }
           },
           { $sort: { activityScore: -1 } },
           { $limit: 10 }
       ]);

       // Format latest activities
       const formattedActivity = latestActivity.map(log => ({
           user: {
               email: log.adminId?.email || 'System'
           },
           action: log.action,
           details: log.details,
           timestamp: log.timestamp
       }));

       // Compile stats
       // Add before the stats compilation
const today = new Date();
today.setHours(0, 0, 0, 0);

const [todayLogins, newArticles, newComments] = await Promise.all([
    User.countDocuments({ lastLogin: { $gte: today } }),
    Article.countDocuments({ createdAt: { $gte: today } }),
    Comment.countDocuments({ createdAt: { $gte: today } }),
    User.countDocuments({ lastLogin: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } })
]);

// Update the stats object
const stats = {
    users: {
        total: totalUsers,
        active: activeUsers,
        inactive: inactiveUsers,
        admins: adminUsers
    },
    content: {
        articles: totalArticles,
        hiddenArticles,
        comments: totalComments
    },
    activity: {
        todayLogins,
        newArticles,
        newComments,
        activeUsers
    },
    mostActiveUsers,
    latestActivity: formattedActivity
};

       res.json({
           success: true,
           data: stats,
           timestamp: new Date().toISOString()
       });

   } catch (error) {
       console.error('Error fetching admin statistics:', error);
       res.status(500).json({
           success: false,
           message: 'Error fetching statistics',
           error: error.message
       });
   }
});
// Article Management Routes
router.get('/articles/stats', checkAdminRole, articleController.getArticleStats);
router.get('/articles', checkAdminRole, articleController.getAllArticles);
router.post('/articles/bulk-delete', checkAdminRole, articleController.bulkDeleteArticles);
router.post('/articles/bulk-toggle', checkAdminRole, articleController.bulkToggleVisibility);
router.delete('/articles/:id', checkAdminRole, articleController.deleteArticle);
router.get('/articles/:id', checkAdminRole, articleController.getArticle);
router.put('/articles/:id', checkAdminRole, articleController.updateArticle);
router.post('/articles/toggle/:id', checkAdminRole, articleController.toggleVisibility);
router.delete('/articles/:id/files/:filename', checkAdminRole, articleController.deleteFile);

// User Management Routes
router.get('/users', checkAdminRole, async (req, res) => {
    try {
        const users = await User.find()
            .select('-password')
            .sort({ createdAt: -1 })
            .lean();
        
        res.json({
            success: true,
            data: users,
            count: users.length
        });
    } catch (error) {
        console.error('Error in /admin/users route:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error fetching users',
            error: error.message 
        });
    }
});

// Password reset route
router.post('/users/:userId/reset-password', checkAdminRole, async (req, res) => {
    try {
        const user = await User.findById(req.params.userId);
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        const tempPassword = `Welcome${Math.floor(100000 + Math.random() * 900000)}!`;
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(tempPassword, salt);

        await User.findByIdAndUpdate(user._id, {
            password: hashedPassword,
            passwordResetRequired: true,
            loginAttempts: 0,
            lockUntil: null,
            $set: {
                passwordResetAt: new Date()
            }
        });

        res.json({
            success: true,
            message: 'Password reset successful',
            data: { 
                temporaryPassword: tempPassword,
                email: user.email,
                requiresReset: true
            }
        });
    } catch (error) {
        console.error('Password reset error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error resetting password',
            error: error.message 
        });
    }
});

// User deletion route
router.delete('/users/:userId', checkAdminRole, async (req, res) => {
    try {
        const user = await User.findById(req.params.userId);
        
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        if (user.role === 'super') {
            return res.status(403).json({ success: false, message: 'Cannot delete super admin' });
        }

        await user.deleteOne();
        res.json({ success: true, message: 'User deleted successfully' });
    } catch (error) {
        console.error('Error deleting user:', error);
        res.status(500).json({ success: false, message: 'Error deleting user' });
    }
});

// Role update route
router.patch('/users/:userId/role', checkSuperAdminRole, async (req, res) => {
    try {
        const { role } = req.body;
        
        if (!['user', 'admin'].includes(role)) {
            return res.status(400).json({ success: false, message: 'Invalid role' });
        }

        const user = await User.findById(req.params.userId);
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        if (user.role === 'super') {
            return res.status(403).json({ success: false, message: 'Cannot modify super admin role' });
        }

        user.role = role;
        await user.save();

        res.json({ success: true, message: 'User role updated successfully' });
    } catch (error) {
        console.error('Error updating user role:', error);
        res.status(500).json({ success: false, message: 'Error updating user role' });
    }
});

module.exports = router;