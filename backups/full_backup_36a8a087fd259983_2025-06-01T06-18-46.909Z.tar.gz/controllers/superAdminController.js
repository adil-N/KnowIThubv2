// controllers/superAdminController.js
const User = require('../models/User');
const Settings = require('../models/Settings');
const AdminLog = require('../models/AdminLog');
const bcrypt = require('bcryptjs');
const ApiResponse = require('../utils/apiResponse');

const logAdminAction = async (adminId, action, details = {}) => {
    try {
        await AdminLog.logActivity({
            adminId,
            action,
            details,
            timestamp: new Date()
        });
    } catch (error) {
        console.error('Error logging admin action:', error);
    }
};

const superAdminController = {
    async createAdmin(req, res) {
        try {
            const { firstName, lastName, email, password, role } = req.body;

            // Validate super admin status
            if (req.user.role !== 'super') {
                return ApiResponse.forbidden(res, 'Only super admins can create admin accounts');
            }

            // Validate email domain
            if (!email.endsWith('@ddf.ae')) {
                return ApiResponse.error(res, 'Email must be from the ddf.ae domain');
            }

            // Check if email exists
            const existingUser = await User.findOne({ email });
            if (existingUser) {
                return ApiResponse.error(res, 'Email already registered');
            }

            // Create admin user
            const hashedPassword = await bcrypt.hash(password, 10);
            const admin = new User({
                firstName,
                lastName,
                email,
                password: hashedPassword,
                role: role === 'super' ? 'super' : 'admin',
                status: 'active',
                passwordResetRequired: true
            });

            await admin.save();

            // Log admin creation
            await logAdminAction(req.user._id, 'ADMIN_CREATED', {
                createdAdminId: admin._id,
                role: admin.role
            });

            return ApiResponse.success(res, 'Admin created successfully', {
                adminId: admin._id
            });
        } catch (error) {
            console.error('Error creating admin:', error);
            return ApiResponse.serverError(res);
        }
    },

    async getAllAdmins(req, res) {
        try {
            const admins = await User.find({
                role: { $in: ['admin', 'super'] }
            }).select('-password -loginAttempts -lockUntil')
              .sort({ createdAt: -1 });

            return ApiResponse.success(res, 'Admins retrieved successfully', admins);
        } catch (error) {
            console.error('Error fetching admins:', error);
            return ApiResponse.serverError(res);
        }
    },

    async getAdmin(req, res) {
        try {
            const { adminId } = req.params;
            const admin = await User.findById(adminId)
                .select('-password -loginAttempts -lockUntil');

            if (!admin) {
                return ApiResponse.notFound(res, 'Admin not found');
            }

            if (!['admin', 'super'].includes(admin.role)) {
                return ApiResponse.error(res, 'User is not an admin');
            }

            return ApiResponse.success(res, 'Admin retrieved successfully', admin);
        } catch (error) {
            console.error('Error fetching admin:', error);
            return ApiResponse.serverError(res);
        }
    },

    async updateAdmin(req, res) {
        try {
            console.log('Update Admin Request:', {
                params: req.params,
                body: req.body,
                user: {
                    id: req.user._id,
                    role: req.user.role
                }
            });

            const { adminId } = req.params;
            const { firstName, lastName, status, role } = req.body;

            // Input validation
            if (!firstName || !lastName || !status || !role) {
                console.log('Missing required fields:', { firstName, lastName, status, role });
                return ApiResponse.error(res, 'All fields are required');
            }

            // Validate user is super admin
            if (req.user.role !== 'super') {
                console.log('Permission denied: User is not super admin');
                return ApiResponse.forbidden(res, 'Only super admins can update admin accounts');
            }

            // Check if trying to modify own role
            if (adminId === req.user._id.toString() && role !== 'super') {
                console.log('Attempted to demote self from super admin');
                return ApiResponse.error(res, 'Cannot demote yourself from super admin');
            }

            // Find admin to update
            const admin = await User.findById(adminId);
            if (!admin) {
                console.log('Admin not found with ID:', adminId);
                return ApiResponse.notFound(res, 'Admin not found');
            }

            console.log('Current admin data:', {
                id: admin._id,
                currentRole: admin.role,
                currentStatus: admin.status
            });

            // Check if attempting to modify a super admin
            if (admin.role === 'super' && adminId !== req.user._id.toString()) {
                console.log('Attempted to modify another super admin');
                return ApiResponse.forbidden(res, 'Cannot modify other super admin accounts');
            }

            // Prepare update data
            const updateData = {
                firstName,
                lastName,
                status,
                role: admin.role === 'super' ? 'super' : role // Prevent changing super admin role
            };

            console.log('Updating admin with data:', updateData);

            // Use findByIdAndUpdate to avoid validation issues
            const updatedAdmin = await User.findByIdAndUpdate(
                adminId,
                updateData,
                { 
                    new: true,
                    runValidators: true,
                    context: 'query'
                }
            );

            if (!updatedAdmin) {
                console.log('Failed to update admin');
                return ApiResponse.error(res, 'Failed to update administrator');
            }

            // Log the admin update action
            await AdminLog.create({
                adminId: req.user._id,
                action: 'ADMIN_UPDATED',
                details: {
                    updatedAdminId: adminId,
                    changes: updateData
                }
            });

            console.log('Admin updated successfully:', updatedAdmin);
            return ApiResponse.success(res, 'Admin updated successfully', updatedAdmin);

        } catch (error) {
            console.error('Error updating admin:', {
                error: error.message,
                stack: error.stack,
                adminId: req.params.adminId,
                requestBody: req.body
            });

            // Handle specific MongoDB errors
            if (error.name === 'ValidationError') {
                return ApiResponse.error(res, Object.values(error.errors).map(err => err.message).join(', '));
            }

            if (error.name === 'CastError') {
                return ApiResponse.error(res, 'Invalid admin ID format');
            }

            return ApiResponse.serverError(res, 'Failed to update administrator');
        }
    },

    async deleteAdmin(req, res) {
        try {
            const { adminId } = req.params;

            if (req.user.role !== 'super') {
                return ApiResponse.forbidden(res, 'Only super admins can delete admin accounts');
            }

            if (adminId === req.user._id.toString()) {
                return ApiResponse.error(res, 'Cannot delete your own account');
            }

            const admin = await User.findById(adminId);
            if (!admin) {
                return ApiResponse.notFound(res, 'Admin not found');
            }

            await admin.deleteOne();

            await logAdminAction(req.user._id, 'ADMIN_DELETED', {
                deletedAdminId: adminId
            });

            return ApiResponse.success(res, 'Admin deleted successfully');
        } catch (error) {
            console.error('Error deleting admin:', error);
            return ApiResponse.serverError(res);
        }
    },

    async resetAdminPassword(req, res) {
        try {
            const { adminId } = req.params;
            console.log(`Password reset initiated for admin ID: ${adminId}`);
    
            // Verify super admin permission
            if (req.user.role !== 'super') {
                return ApiResponse.forbidden(res, 'Only super admins can reset passwords');
            }
    
            // Find the admin user
            const admin = await User.findById(adminId);
            if (!admin) {
                return ApiResponse.notFound(res, 'Admin not found');
            }
    
            // Generate a new temporary password
            const temporaryPassword = Math.random().toString(36).slice(-8);
            
            // Set the new password directly (User model will hash it)
            admin.password = temporaryPassword;
            admin.passwordResetRequired = true;
            admin.loginAttempts = 0;
            admin.lockUntil = null;
    
            // Save changes
            await admin.save();
    
            // Verify the new password works
            const verificationResult = await admin.comparePassword(temporaryPassword);
            console.log('Password reset verification:', {
                temporaryPassword,
                verified: verificationResult,
                adminEmail: admin.email,
                passwordResetRequired: admin.passwordResetRequired
            });
    
            if (!verificationResult) {
                throw new Error('Password verification failed after reset');
            }
    
            // Log the action
            await logAdminAction(req.user._id, 'ADMIN_PASSWORD_RESET', {
                adminId: admin._id,
                timestamp: new Date()
            });
    
            // Return success response
            return ApiResponse.success(res, 'Password reset successful', {
                temporaryPassword,
                email: admin.email,
                requiresReset: true
            });
    
        } catch (error) {
            console.error('Password reset error:', error);
            return ApiResponse.serverError(res, 'Failed to reset password');
        }
    },

    async getSettings(req, res) {
        try {
            const settings = await Settings.findOne();
            return ApiResponse.success(res, 'Settings retrieved successfully', settings || {});
        } catch (error) {
            console.error('Error fetching settings:', error);
            return ApiResponse.serverError(res);
        }
    },

    async updateSettings(req, res) {
        try {
            const settings = req.body;

            if (req.user.role !== 'super') {
                return ApiResponse.forbidden(res, 'Only super admins can update system settings');
            }

            await Settings.findOneAndUpdate({}, settings, { upsert: true });

            await logAdminAction(req.user._id, 'SETTINGS_UPDATED', {
                changes: settings
            });

            return ApiResponse.success(res, 'Settings updated successfully');
        } catch (error) {
            console.error('Error updating settings:', error);
            return ApiResponse.serverError(res);
        }
    },

    async getAdminLogs(req, res) {
        try {
            const { limit = 20 } = req.query;
            const logs = await AdminLog.getRecentLogs(parseInt(limit));
            return ApiResponse.success(res, 'Logs retrieved successfully', logs);
        } catch (error) {
            console.error('Error fetching admin logs:', error);
            return ApiResponse.serverError(res);
        }
    },

    async exportLogs(req, res) {
        try {
            const { start, end } = req.query;
            const logs = await AdminLog.getLogsByDateRange(start, end);
            const csv = this.convertLogsToCSV(logs);

            res.setHeader('Content-Type', 'text/csv');
            res.setHeader('Content-Disposition', 'attachment; filename=admin_logs.csv');
            return res.send(csv);
        } catch (error) {
            console.error('Error exporting logs:', error);
            return ApiResponse.serverError(res);
        }
    },

    convertLogsToCSV(logs) {
        const headers = ['Timestamp', 'Admin', 'Action', 'Details'];
        const rows = logs.map(log => [
            new Date(log.timestamp).toISOString(),
            log.adminId,
            log.action,
            JSON.stringify(log.details)
        ]);

        return [headers, ...rows].map(row => row.join(',')).join('\n');
    }
};

module.exports = superAdminController;