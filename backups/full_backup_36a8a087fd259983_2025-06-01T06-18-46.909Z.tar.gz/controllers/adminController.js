// controllers/adminController.js
const User = require('../models/User');
const Article = require('../models/Article');
const Comment = require('../models/Comment');
const bcrypt = require('bcryptjs');
const inviteCodeManager = require('../utils/inviteCodeManager');
const ApiResponse = require('../utils/apiResponse');
const AdminLog = require('../models/AdminLog');


const adminController = {
    getStats: async (req, res) => {
        try {
            // Basic stats
            const [totalUsers, activeUsers, inactiveUsers, adminUsers] = await Promise.all([
                User.countDocuments(),
                User.countDocuments({ status: 'active' }),
                User.countDocuments({ status: 'inactive' }),
                User.countDocuments({ role: 'admin' })
            ]);

            const [totalArticles, hiddenArticles, totalComments] = await Promise.all([
                Article.countDocuments(),
                Article.countDocuments({ hidden: true }),
                Comment.countDocuments()
            ]);

            // Most Active Users with weighted scoring
            // In adminController.js, update the mostActiveUsers aggregation:

const mostActiveUsers = await User.aggregate([
    {
        $lookup: {
            from: 'articles',
            localField: '_id',
            foreignField: 'author',
            as: 'articles'
        }
    },
    {
        $lookup: {
            from: 'comments',
            localField: '_id',
            foreignField: 'author',
            as: 'comments'
        }
    },
    {
        $addFields: {
            articleCount: { $size: '$articles' },
            commentCount: { $size: '$comments' },
            // Track the most recent activity between lastLogin and most recent content
            lastActive: {
                $max: [
                    '$lastLogin',
                    { $max: '$articles.createdAt' },
                    { $max: '$comments.createdAt' }
                ]
            },
            lastWeekLogin: {
                $cond: {
                    if: {
                        $gte: ['$lastLogin', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)]
                    },
                    then: 5,
                    else: 0
                }
            }
        }
    },
    {
        $addFields: {
            activityScore: {
                $add: [
                    { $multiply: ['$articleCount', 10] }, // Articles weight more
                    { $multiply: ['$commentCount', 2] },  // Comments weight
                    '$lastWeekLogin'  // Recent login bonus
                ]
            }
        }
    },
    {
        $project: {
            email: 1,
            firstName: 1,
            lastName: 1,
            articleCount: 1,
            commentCount: 1,
            lastActive: 1,  // Include lastActive in projection
            activityScore: 1
        }
    },
    { $sort: { activityScore: -1 } },
    { $limit: 10 }
]);

            // Top 10 Articles by engagement
            const topArticles = await Article.aggregate([
                {
                    $lookup: {
                        from: 'comments',
                        localField: '_id',
                        foreignField: 'article',
                        as: 'comments'
                    }
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: 'author',
                        foreignField: '_id',
                        as: 'authorDetails'
                    }
                },
                {
                    $addFields: {
                        commentCount: { $size: '$comments' },
                        author: { $arrayElemAt: ['$authorDetails', 0] }
                    }
                },
                {
                    $addFields: {
                        engagementScore: {
                            $add: [
                                { $multiply: ['$commentCount', 2] },  // Comments weight
                                { $ifNull: ['$views', 0] }           // Views weight
                            ]
                        }
                    }
                },
                {
                    $project: {
                        title: 1,
                        'author.email': 1,
                        commentCount: 1,
                        views: 1,
                        createdAt: 1,
                        engagementScore: 1
                    }
                },
                { $sort: { engagementScore: -1 } },
                { $limit: 10 }
            ]);

            // Latest User Activity
            const latestActivity = await AdminLog.aggregate([
                {
                    $lookup: {
                        from: 'users',
                        localField: 'adminId',
                        foreignField: '_id',
                        as: 'user'
                    }
                },
                { $unwind: '$user' },
                {
                    $project: {
                        'user.email': 1,
                        action: 1,
                        details: 1,
                        timestamp: 1
                    }
                },
                { $sort: { timestamp: -1 } },
                { $limit: 20 }
            ]);

            // User Contributions (sorted by total contribution)
            const userContributions = await User.aggregate([
                {
                    $lookup: {
                        from: 'articles',
                        localField: '_id',
                        foreignField: 'author',
                        as: 'articles'
                    }
                },
                {
                    $lookup: {
                        from: 'comments',
                        localField: '_id',
                        foreignField: 'author',
                        as: 'comments'
                    }
                },
                {
                    $addFields: {
                        articlesCount: { $size: '$articles' },
                        commentsCount: { $size: '$comments' },
                        totalContributions: {
                            $add: [
                                { $size: '$articles' },
                                { $size: '$comments' }
                            ]
                        }
                    }
                },
                {
                    $project: {
                        email: 1,
                        role: 1,
                        lastLogin: 1,
                        articlesCount: 1,
                        commentsCount: 1,
                        totalContributions: 1
                    }
                },
                { $sort: { totalContributions: -1 } }
            ]);

            // Activity Timeline (last 7 days)
            const last7Days = [...Array(7)].map((_, i) => {
                const date = new Date();
                date.setDate(date.getDate() - (6 - i));
                return date.toISOString().split('T')[0];
            });

            const activityPromises = last7Days.map(async date => {
                const startDate = new Date(date);
                const endDate = new Date(date);
                endDate.setDate(endDate.getDate() + 1);

                const [logins, articles, comments] = await Promise.all([
                    User.countDocuments({
                        lastLogin: { $gte: startDate, $lt: endDate }
                    }),
                    Article.countDocuments({
                        createdAt: { $gte: startDate, $lt: endDate }
                    }),
                    Comment.countDocuments({
                        createdAt: { $gte: startDate, $lt: endDate }
                    })
                ]);

                return {
                    date,
                    logins,
                    articles,
                    comments,
                    total: logins + articles + comments
                };
            });

            const activityData = await Promise.all(activityPromises);

            // Compile all stats
            const stats = {
                users: {
                    total: totalUsers,
                    active: activeUsers,
                    inactive: inactiveUsers,
                    admins: adminUsers
                },
                content: {
                    articles: totalArticles,
                    comments: totalComments,
                    hiddenArticles
                },
                mostActiveUsers,
                topArticles,
                latestActivity,
                userContributions,
                userActivity: {
                    labels: activityData.map(d => d.date),
                    values: activityData.map(d => d.total)
                },
                contentGrowth: {
                    labels: activityData.map(d => d.date),
                    articles: activityData.map(d => d.articles),
                    comments: activityData.map(d => d.comments)
                },
                system: {
                    lastBackup: process.env.LAST_BACKUP_DATE || null,
                    storageUsed: await calculateStorageUsed()
                }
            };

            res.json({
                success: true,
                data: stats,
                timestamp: new Date().toISOString()
            });

        } catch (error) {
            console.error('Error fetching admin statistics:', error);
            res.status(500).json({
                success: false,
                message: 'Error fetching statistics',
                error: error.message
            });
        }
    },
    

    // Get all users Get user method
    getUsers: async (req, res) => {
        try {
            const users = await User.find()
                .select('email firstName lastName role status createdAt lastLogin')
                .sort({ createdAt: -1 })
                .lean();

            // Always return in this consistent format
            return res.json({
                success: true,
                data: users,
                count: users.length,
                timestamp: new Date().toISOString()
            });
        } catch (error) {
            console.error('Error fetching users:', error);
            return res.status(500).json({
                success: false,
                message: 'Error fetching users',
                error: error.message
            });
        }
    },
    
    // Get admin users
    getAdmins: async (req, res) => {
        try {
            const admins = await User.find({ role: 'admin' })
                .select('-password')
                .sort({ createdAt: -1 });
            res.json({ success: true, data: admins });
        } catch (error) {
            console.error('Error fetching admins:', error);
            res.status(500).json({ success: false, message: 'Error fetching admins' });
        }
    },

    // Reset user password
    // In adminController.js, update the resetUserPassword method
resetUserPassword: async (req, res) => {
    try {
        const user = await User.findById(req.params.userId);
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        // Generate a simpler but still secure temporary password
        const tempPassword = `TempPass${Math.floor(10000 + Math.random() * 90000)}`; // Format: TempPass12345

        // Hash the password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(tempPassword, salt);

        // Update user with new password and force reset
        await User.findByIdAndUpdate(user._id, {
            password: hashedPassword,
            passwordResetRequired: true,
            loginAttempts: 0,
            lockUntil: null,
            $set: {
                passwordResetAt: new Date()
            }
        });

        console.log('Password reset completed for user:', user.email);
        console.log('New temp password (hashed):', hashedPassword);

        res.json({
            success: true,
            message: 'Password reset successful',
            data: { 
                temporaryPassword: tempPassword,
                email: user.email,
                requiresReset: true
            }
        });
    } catch (error) {
        console.error('Error resetting password:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error resetting password',
            error: error.message 
        });
    }
},

    // Delete user
    deleteUser: async (req, res) => {
        try {
            const user = await User.findById(req.params.userId);
            if (!user) {
                return res.status(404).json({ success: false, message: 'User not found' });
            }

            if (user.role === 'super') {
                return res.status(403).json({ success: false, message: 'Cannot delete super admin' });
            }

            await user.deleteOne();
            res.json({ success: true, message: 'User deleted successfully' });
        } catch (error) {
            console.error('Error deleting user:', error);
            res.status(500).json({ success: false, message: 'Error deleting user' });
        }
    },

    // Update user status
    updateUserStatus: async (req, res) => {
        try {
            const { status } = req.body;
            if (!['active', 'inactive', 'suspended'].includes(status)) {
                return res.status(400).json({ success: false, message: 'Invalid status' });
            }

            const user = await User.findById(req.params.userId);
            if (!user) {
                return res.status(404).json({ success: false, message: 'User not found' });
            }

            if (user.role === 'super') {
                return res.status(403).json({ success: false, message: 'Cannot modify super admin status' });
            }

            user.status = status;
            await user.save();

            res.json({ success: true, message: 'User status updated successfully' });
        } catch (error) {
            console.error('Error updating user status:', error);
            res.status(500).json({ success: false, message: 'Error updating user status' });
        }
    },

    // Update user role (super admin only)
    updateUserRole: async (req, res) => {
        try {
            const { role } = req.body;
            if (!['user', 'admin'].includes(role)) {
                return res.status(400).json({ success: false, message: 'Invalid role' });
            }

            const user = await User.findById(req.params.userId);
            if (!user) {
                return res.status(404).json({ success: false, message: 'User not found' });
            }

            if (user.role === 'super') {
                return res.status(403).json({ success: false, message: 'Cannot modify super admin role' });
            }

            user.role = role;
            await user.save();

            res.json({ success: true, message: 'User role updated successfully' });
        } catch (error) {
            console.error('Error updating user role:', error);
            res.status(500).json({ success: false, message: 'Error updating user role' });
        }
    },
    
    // Update admin name
    updateAdminName: async (req, res) => {
        try {
            const { firstName, lastName } = req.body;
            const admin = await User.findById(req.params.adminId);
            
            if (!admin || admin.role !== 'admin') {
                return res.status(404).json({ success: false, message: 'Admin not found' });
            }

            admin.firstName = firstName;
            admin.lastName = lastName;
            await admin.save();

            res.json({ success: true, message: 'Admin name updated successfully' });
        } catch (error) {
            console.error('Error updating admin name:', error);
            res.status(500).json({ success: false, message: 'Error updating admin name' });
        }
    }
    
};
// Helper function to calculate storage used
async function calculateStorageUsed() {
    try {
        const articleStorage = await Article.aggregate([
            {
                $group: {
                    _id: null,
                    total: {
                        $sum: { $ifNull: ['$fileSize', 0] }
                    }
                }
            }
        ]);

        return articleStorage[0]?.total || 0;
    } catch (error) {
        console.error('Error calculating storage:', error);
        return 0;
    }
}


module.exports = {
    ...adminController,
    //...inviteCodeController
};