// frontend/src/js/admin/adminPanel.js
import { api } from '../utils/api.js';
import { ui } from '../utils/ui.js';
import { articleManagement } from './articleManagement.js';
import { statsManagement } from './statsManagement.js';
import { inviteCodeManagement } from './inviteCodeManagement.js';
import { sectionManagement } from './sectionManagement.js';
import { systemBackup } from './systemBackup.js';  // Ensure correct import

console.log('Imported systemBackup:', systemBackup);

export async function showAdminPanel() {
    try {
        console.log('Initializing admin panel...');
        ui.showLoading();
        
        // First, show the section
        ui.showSection('adminPanelContainer');
        
        // Then initialize the panel
        await initializeAdminPanel();
        
        console.log('Admin panel initialized successfully');
    } catch (error) {
        console.error('Error showing admin panel:', error);
        ui.showError('Failed to initialize admin panel');
    } finally {
        ui.hideLoading();
    }
}

export const initializeAdminPanel = async () => {
    console.log('Setting up admin panel content...');
    const adminPanelContainer = document.getElementById('adminPanelContainer');
    if (!adminPanelContainer) {
        console.error('Admin panel container not found');
        throw new Error('Admin panel container not found');
    }

    // Clear any existing content
    adminPanelContainer.innerHTML = '';

    // Add the adminPanelTemplate
    const adminPanelTemplate = `
        <div class="bg-white rounded-lg shadow-md p-6 max-w-8xl mx-auto">
            <h2 class="text-2xl font-bold mb-6">Admin Dashboard</h2>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div class="p-4 bg-blue-100 rounded-lg">
                    <h3 class="font-semibold mb-2">User Management</h3>
                    <button id="showUsers" class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition duration-300 flex items-center">
                        <span class="material-icons-outlined mr-2">people</span>
                        Manage Users
                    </button>
                </div>

                <div class="p-4 bg-green-100 rounded-lg">
                    <h3 class="font-semibold mb-2">Content Management</h3>
                    <button id="showContent" class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition duration-300 flex items-center">
                        <span class="material-icons-outlined mr-2">insert_drive_file</span>
                        Manage Content
                    </button>
                </div>

                <div class="p-4 bg-purple-100 rounded-lg">
                    <h3 class="font-semibold mb-2">Statistics</h3>
                    <button id="showStats" class="px-4 py-2 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition duration-300 flex items-center">
                        <span class="material-icons-outlined mr-2">bar_chart</span>
                        View Stats
                    </button>
                </div>

                <div class="p-4 bg-indigo-100 rounded-lg">
                    <h3 class="font-semibold mb-2">Generate Invitation Code</h3>
                    <button id="generateNewCode" class="px-4 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 transition duration-300 flex items-center">
                        <span class="material-icons-outlined mr-2">link</span>
                        Generate Code
                    </button>
                </div>

                <div class="p-4 bg-amber-100 rounded-lg">
                    <h3 class="font-semibold mb-2">Section Management</h3>
                    <button id="showSections" class="px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition duration-300 flex items-center">
                        <span class="material-icons-outlined mr-2">view_quilt</span>
                        Manage Sections
                    </button>
                </div>

                <div class="p-4 bg-blue-100 rounded-lg">
                    <h3 class="font-semibold mb-2">System Backup</h3>
                    <button id="showBackup" class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition duration-300 flex items-center">
                        <span class="material-icons-outlined mr-2">backup</span>
                        Backup System
                    </button>
                </div>
            </div>

            <div id="adminContent" class="mt-6">
                <!-- Content will be loaded here -->
            </div>
        </div>
    `;

    adminPanelContainer.innerHTML = adminPanelTemplate;

    // Remove any existing event listeners
    const removeOldListeners = () => {
        const oldShowUsers = document.getElementById('showUsers');
        const oldShowContent = document.getElementById('showContent');
        const oldShowStats = document.getElementById('showStats');
        const oldGenerateCode = document.getElementById('generateNewCode');
        const oldShowSections = document.getElementById('showSections');
        const oldShowBackup = document.getElementById('showBackup');

        if (oldShowUsers) oldShowUsers.replaceWith(oldShowUsers.cloneNode(true));
        if (oldShowContent) oldShowContent.replaceWith(oldShowContent.cloneNode(true));
        if (oldShowStats) oldShowStats.replaceWith(oldShowStats.cloneNode(true));
        if (oldGenerateCode) oldGenerateCode.replaceWith(oldGenerateCode.cloneNode(true));
        if (oldShowSections) oldShowSections.replaceWith(oldShowSections.cloneNode(true));
        if (oldShowBackup) oldShowBackup.replaceWith(oldShowBackup.cloneNode(true));
    };

    removeOldListeners();

    // Add new event listeners
    document.getElementById('showUsers')?.addEventListener('click', loadUserManagement);
    document.getElementById('showContent')?.addEventListener('click', loadContentManagement);
    document.getElementById('showStats')?.addEventListener('click', loadStatistics);
    document.getElementById('generateNewCode')?.addEventListener('click', handleGenerateNewCode);
    document.getElementById('showSections')?.addEventListener('click', loadSectionManagement);
    document.getElementById('showBackup')?.addEventListener('click', () => {
        try {
            const adminContent = document.getElementById('adminContent');
            if (adminContent) {
                systemBackup.showBackupManager(adminContent);
            }
        } catch (error) {
            console.error('Error in backup manager:', error);
            ui.showError('Failed to load backup management');
        }
    });

    // Load user management by default
    await loadUserManagement();
};


// Add the handle generate code function
async function handleGenerateNewCode() {
    try {
        ui.showLoading();
        const response = await api.post('/api/admin/invite-codes/generate', {
            expiresInDays: 30,
            maxUses: 1
        });

        if (response.success) {
            const modal = document.createElement('div');
            modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
            modal.innerHTML = `
                <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-semibold">New Invite Code</h3>
                        <button class="text-gray-500 hover:text-gray-700" onclick="this.closest('.fixed').remove()">✕</button>
                    </div>
                    <div class="mb-4">
                        <p class="text-sm text-gray-600 mb-2">New invite code:</p>
                        <div class="flex items-center space-x-2">
                            <div class="relative flex-1">
                                <input 
                                    type="text" 
                                    value="${response.data.code}" 
                                    class="w-full p-2 border rounded bg-gray-50 pr-24" 
                                    id="newInviteCode"
                                    readonly
                                />
                                <button 
                                    id="copyCodeBtn"
                                    class="absolute right-2 top-1/2 transform -translate-y-1/2 bg-indigo-500 text-white px-4 py-1 rounded hover:bg-indigo-600 text-sm"
                                >
                                    Copy
                                </button>
                            </div>
                        </div>
                    </div>
                    <p class="text-sm text-gray-500">Please save this code. For security reasons, it will not be shown again.</p>
                </div>
            `;
            document.body.appendChild(modal);

            // Set up copy functionality
            const copyBtn = modal.querySelector('#copyCodeBtn');
            const codeField = modal.querySelector('#newInviteCode');

            copyBtn.addEventListener('click', () => {
                codeField.select();
                document.execCommand('copy');
                
                // Visual feedback
                copyBtn.textContent = 'Copied!';
                copyBtn.classList.remove('bg-indigo-500', 'hover:bg-indigo-600');
                copyBtn.classList.add('bg-green-500', 'hover:bg-green-600');
                
                setTimeout(() => {
                    copyBtn.textContent = 'Copy';
                    copyBtn.classList.remove('bg-green-500', 'hover:bg-green-600');
                    copyBtn.classList.add('bg-indigo-500', 'hover:bg-indigo-600');
                }, 1500);

                ui.showError('Code copied to clipboard!', 'success');
            });

            // Focus the input for easy keyboard shortcut (Ctrl+C)
            codeField.focus();
            codeField.select();
        }
    } catch (error) {
        console.error('Error generating new code:', error);
        ui.showError('Failed to generate new invite code');
    } finally {
        ui.hideLoading();
    }
}


async function loadUserManagement() {
    const adminContent = document.getElementById('adminContent');
    if (!adminContent) return;

    try {
        ui.showLoading();
        const response = await api.get('/api/admin/users');
        
        console.log('User Management Response:', response); // Debug log
        
        if (!response.success) {
            throw new Error(response.message || 'Failed to load users');
        }

        const users = (response.data || []).filter(user => user.role !== 'super');
        
        const usersList = users.map(user => `
            <tr>
                <td class="border px-4 py-2">${user.email}</td>
                <td class="border px-4 py-2">${user.firstName} ${user.lastName}</td>
                <td class="border px-4 py-2">${user.role}</td>
                <td class="border px-4 py-2">${user.status || 'active'}</td>
                <td class="border px-4 py-2">
                    <button onclick="window.resetUserPassword('${user._id}')" 
                        class="bg-yellow-500 text-white px-2 py-1 rounded mr-2 hover:bg-yellow-600">
                        Reset Password
                    </button>
                    <button onclick="window.deleteUser('${user._id}')" 
                        class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600">
                        Delete
                    </button>
                </td>
            </tr>
        `).join('');

        adminContent.innerHTML = `
            <div class="w-full">
                <h2 class="text-2xl font-bold mb-4">User Management</h2>
                <div class="overflow-x-auto bg-white rounded-lg shadow">
                    <table class="min-w-full bg-white">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="border px-4 py-2 text-left">Email</th>
                                <th class="border px-4 py-2 text-left">Name</th>
                                <th class="border px-4 py-2 text-left">Role</th>
                                <th class="border px-4 py-2 text-left">Status</th>
                                <th class="border px-4 py-2 text-left">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${usersList}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    } catch (error) {
        console.error('Error loading users:', error);
        adminContent.innerHTML = `
            <div class="text-red-500 p-4">
                Error loading users: ${error.message || 'Unknown error'}
            </div>
        `;
        ui.showError('Failed to load users');
    } finally {
        ui.hideLoading();
    }
}

async function loadContentManagement() {
    const adminContent = document.getElementById('adminContent');
    if (!adminContent) return;

    try {
        ui.showLoading();
        const response = await api.get('/api/admin/articles');
        
        if (!response || !response.success) {
            throw new Error(response?.message || 'Failed to load articles');
        }

        await articleManagement.show(response.data);
    } catch (error) {
        console.error('Error loading content management:', error);
        adminContent.innerHTML = '<p class="text-red-500">Error loading content: ' + (error.message || 'Unknown error') + '</p>';
        ui.showError('Failed to load content management');
    } finally {
        ui.hideLoading();
    }
}

// In adminPanel.js, update the loadStatistics function

async function loadStatistics() {
    const adminContent = document.getElementById('adminContent');
    if (!adminContent) return;

    try {
        ui.showLoading();
        
        // Inject required script for Charts
        if (!document.getElementById('chartjs-script')) {
            const script = document.createElement('script');
            script.id = 'chartjs-script';
            script.src = 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js';
            document.head.appendChild(script);
            
            // Wait for Chart.js to load
            await new Promise((resolve) => {
                script.onload = resolve;
            });
        }

        // Call the comprehensive stats management show method
        await statsManagement.show(adminContent);
        
    } catch (error) {
        console.error('Error loading statistics:', error);
        if (adminContent) {
            adminContent.innerHTML = `
                <div class="text-red-500">
                    Error loading statistics: ${error.message || 'Unknown error'}
                </div>
            `;
        }
        ui.showError('Failed to load statistics');
    } finally {
        ui.hideLoading();
    }
}

//funtion of invitation code
async function loadInviteCodeManagement() {
    const adminContent = document.getElementById('adminContent');
    if (!adminContent) return;

    try {
        ui.showLoading();
        await inviteCodeManagement.show(adminContent);
    } catch (error) {
        console.error('Error loading invite code management:', error);
        adminContent.innerHTML = `
            <div class="text-red-500">
                Error loading invite code management: ${error.message || 'Unknown error'}
            </div>
        `;
        ui.showError('Failed to load invite code management');
    } finally {
        ui.hideLoading();
    }
}
// Add the loadSectionManagement function:
async function loadSectionManagement() {
    const adminContent = document.getElementById('adminContent');
    if (!adminContent) return;

    try {
        ui.showLoading();
        await sectionManagement.show(adminContent);
    } catch (error) {
        console.error('Error loading section management:', error);
        adminContent.innerHTML = `
            <div class="text-red-500 p-4">
                Error loading section management: ${error.message || 'Unknown error'}
            </div>
        `;
        ui.showError('Failed to load section management');
    } finally {
        ui.hideLoading();
    }
}
// Add global handlers for user actions
// In adminPanel.js, update the password reset modal code
window.resetUserPassword = async (userId) => {
    if (!confirm('Are you sure you want to reset this user\'s password?')) return;

    try {
        ui.showLoading();
        const response = await api.post(`/api/admin/users/${userId}/reset-password`);
        
        if (!response || !response.success) {
            throw new Error(response?.message || 'Failed to reset password');
        }

        // Create and show modal with copy functionality
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold">Temporary Password</h3>
                    <button class="text-gray-500 hover:text-gray-700" onclick="this.closest('.fixed').remove()">✕</button>
                </div>
                <div class="mb-4">
                    <p class="text-sm text-gray-600 mb-2">New temporary password:</p>
                    <div class="flex items-center space-x-2">
                        <div class="relative flex-1">
                            <input 
                                type="text" 
                                value="${response.data.temporaryPassword}" 
                                class="w-full p-2 border rounded bg-gray-50 pr-24" 
                                id="tempPasswordField"
                                readonly
                            />
                            <button 
                                id="copyPasswordBtn"
                                class="absolute right-2 top-1/2 transform -translate-y-1/2 bg-blue-500 text-white px-4 py-1 rounded hover:bg-blue-600 text-sm"
                            >
                                Copy
                            </button>
                        </div>
                    </div>
                </div>
                <p class="text-sm text-gray-500">Please share this password securely with the user.</p>
            </div>
        `;

        document.body.appendChild(modal);

        // Set up copy functionality
        const copyBtn = modal.querySelector('#copyPasswordBtn');
        const tempPasswordField = modal.querySelector('#tempPasswordField');

        copyBtn.addEventListener('click', () => {
            tempPasswordField.select();
            document.execCommand('copy');
            
            // Visual feedback
            copyBtn.textContent = 'Copied!';
            copyBtn.classList.remove('bg-blue-500', 'hover:bg-blue-600');
            copyBtn.classList.add('bg-green-500', 'hover:bg-green-600');
            
            setTimeout(() => {
                copyBtn.textContent = 'Copy';
                copyBtn.classList.remove('bg-green-500', 'hover:bg-green-600');
                copyBtn.classList.add('bg-blue-500', 'hover:bg-blue-600');
            }, 1500);

            // Show toast notification
            ui.showError('Password copied to clipboard!', 'success');
        });

        // Focus the input for easy keyboard shortcut (Ctrl+C)
        tempPasswordField.focus();
        tempPasswordField.select();

    } catch (error) {
        console.error('Error resetting password:', error);
        ui.showError(error.message || 'Failed to reset password');
    } finally {
        ui.hideLoading();
    }
};

window.deleteUser = async (userId) => {
    if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) return;

    try {
        ui.showLoading();
        const response = await api.delete(`/api/admin/users/${userId}`);
        
        if (!response || !response.success) {
            throw new Error(response?.message || 'Failed to delete user');
        }

        await loadUserManagement();
        ui.showError('User deleted successfully', 'success');
    } catch (error) {
        console.error('Error deleting user:', error);
        ui.showError(error.message || 'Failed to delete user');
    } finally {
        ui.hideLoading();
    }
};

