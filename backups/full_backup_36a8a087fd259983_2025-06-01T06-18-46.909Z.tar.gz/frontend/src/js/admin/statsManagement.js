  // frontend/src/js/admin/statsManagement.js
import { api } from '../utils/api.js';
import { ui } from '../utils/ui.js';

export const statsManagement = {
    async show(adminContent) {
        if (!adminContent) return;
    
        try {
            ui.showLoading();
            const response = await api.get('/api/admin/stats');
            console.log('Stats API Response:', response);
            
            if (response.success) {
                this.renderStats(response.data, adminContent);
                this.startAutoRefresh();
            } else {
                throw new Error(response?.message || 'Failed to load statistics');
            }
        } catch (error) {
            console.error('Error loading statistics:', error);
            adminContent.innerHTML = `
                <div class="text-red-500 p-4">
                    Error loading statistics: ${error.message || 'Unknown error'}
                </div>
            `;
            ui.showError('Failed to load statistics');
        } finally {
            ui.hideLoading();
        }
    },

    renderStats(stats, adminContent) {
        if (!adminContent) return;
        
        console.log('Processing stats data:', stats);
    
        const safeStats = {
            users: stats?.users || { total: 0, active: 0, inactive: 0, admins: 0 },
            content: stats?.content || { articles: 0, comments: 0, hiddenArticles: 0 },
            activity: stats?.activity || { todayLogins: 0, newArticles: 0, activeUsers: 0, newComments: 0 },
            mostActiveUsers: stats?.mostActiveUsers || [],
            latestActivity: stats?.latestActivity || []
        };
    
        adminContent.innerHTML = `
            <div class="space-y-6 p-6">
                <h2 class="text-2xl font-bold text-gray-800">Statistics Dashboard</h2>
                
                <!-- Primary Stats Grid -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <!-- User Stats Card -->
                    <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
                        <div class="p-4">
                            <h3 class="text-lg font-semibold text-gray-700">Total Users</h3>
                            <p class="text-3xl font-bold text-blue-600 mt-2">${safeStats.users.total}</p>
                            <div class="mt-4 space-y-2">
                                <div class="flex justify-between items-center text-sm">
                                    <span class="text-gray-600">Active Users</span>
                                    <span class="font-medium text-green-600">${safeStats.users.active}</span>
                                </div>
                                <div class="flex justify-between items-center text-sm">
                                    <span class="text-gray-600">Inactive Users</span>
                                    <span class="font-medium text-red-600">${safeStats.users.inactive}</span>
                                </div>
                                <div class="flex justify-between items-center text-sm">
                                    <span class="text-gray-600">Admins</span>
                                    <span class="font-medium text-purple-600">${safeStats.users.admins}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Content Stats Card -->
                    <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
                        <div class="p-4">
                            <h3 class="text-lg font-semibold text-gray-700">Content Overview</h3>
                            <p class="text-3xl font-bold text-green-600 mt-2">${safeStats.content.articles}</p>
                            <div class="mt-4 space-y-2">
                                <div class="flex justify-between items-center text-sm">
                                    <span class="text-gray-600">Visible Articles</span>
                                    <span class="font-medium text-green-600">${safeStats.content.articles - safeStats.content.hiddenArticles}</span>
                                </div>
                                <div class="flex justify-between items-center text-sm">
                                    <span class="text-gray-600">Hidden Articles</span>
                                    <span class="font-medium text-yellow-600">${safeStats.content.hiddenArticles}</span>
                                </div>
                                <div class="flex justify-between items-center text-sm">
                                    <span class="text-gray-600">Total Comments</span>
                                    <span class="font-medium text-blue-600">${safeStats.content.comments}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Today's Activity Card -->
                    <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 col-span-2">
                        <div class="p-4">
                            <h3 class="text-lg font-semibold text-gray-700">Today's Activity</h3>
                            <div class="grid grid-cols-2 gap-4 mt-4">
                                <div class="bg-blue-50 rounded-lg p-3">
                                    <p class="text-sm text-gray-600">Today's Logins</p>
                                    <p class="text-2xl font-bold text-blue-600">${safeStats.activity.todayLogins}</p>
                                </div>
                                <div class="bg-green-50 rounded-lg p-3">
                                    <p class="text-sm text-gray-600">New Articles</p>
                                    <p class="text-2xl font-bold text-green-600">${safeStats.activity.newArticles}</p>
                                </div>
                                <div class="bg-purple-50 rounded-lg p-3">
                                    <p class="text-sm text-gray-600">Active Users</p>
                                    <p class="text-2xl font-bold text-purple-600">${safeStats.activity.activeUsers}</p>
                                </div>
                                <div class="bg-amber-50 rounded-lg p-3">
                                    <p class="text-sm text-gray-600">New Comments</p>
                                    <p class="text-2xl font-bold text-amber-600">${safeStats.activity.newComments}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Latest Activity Table -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-gray-700 mb-4">Latest Activity</h3>
                        ${this.renderLatestActivityTable(safeStats.latestActivity)}
                    </div>
                </div>

                <!-- Most Active Users Table -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold text-gray-700 mb-4">Most Active Users</h3>
                        ${this.renderActiveUsersTable(safeStats.mostActiveUsers)}
                    </div>
                </div>
            </div>
        `;
    },

    renderActiveUsersTable(users = []) {
        return `
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">User</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Activity Score</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Articles</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Comments</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Last Active</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        ${users.map(user => `
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div>
                                            <div class="text-sm font-medium text-gray-900">${user.email}</div>
                                            <div class="text-sm text-gray-500">${user.firstName} ${user.lastName}</div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">${user.activityScore}</div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${user.articleCount}</td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${user.commentCount}</td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${this.formatDate(user.lastLogin)}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    },

    renderLatestActivityTable(activities = []) {
        return `
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200 latest-activity-table">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Admin</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Details</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        ${activities.map(activity => `
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900">${activity.user?.email || 'System'}</div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 py-1 text-xs rounded-full ${this.getActivityBadgeColor(activity.action)}">
                                        ${this.formatActivityAction(activity.action)}
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-500">${this.formatActivityDetails(activity.details)}</div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    ${this.formatDate(activity.timestamp)}
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    },

    getActivityBadgeColor(action) {
        const colors = {
            'USER_LOGIN': 'bg-green-100 text-green-800',
            'USER_CREATED': 'bg-blue-100 text-blue-800',
            'USER_UPDATED': 'bg-yellow-100 text-yellow-800',
            'USER_DELETED': 'bg-red-100 text-red-800',
            'ARTICLE_CREATED': 'bg-purple-100 text-purple-800',
            'ARTICLE_UPDATED': 'bg-indigo-100 text-indigo-800',
            'ARTICLE_DELETED': 'bg-red-100 text-red-800',
            'COMMENT_ADDED': 'bg-emerald-100 text-emerald-800',
            'DEFAULT': 'bg-gray-100 text-gray-800'
        };
        return colors[action] || colors.DEFAULT;
    },

    formatActivityAction(action) {
        return action.split('_').map(word => 
            word.charAt(0) + word.slice(1).toLowerCase()
        ).join(' ');
    },

    formatActivityDetails(details) {
        if (!details) return '';
        if (typeof details === 'string') return details;
        return Object.entries(details)
            .map(([key, value]) => `${key}: ${value}`)
            .join(', ');
    },

    formatDate(date) {
        if (!date) return 'Never';
        try {
            const dateObj = new Date(date);
            if (isNaN(dateObj.getTime())) return 'Invalid Date';
            
            const now = new Date();
            const diffInHours = (now - dateObj) / (1000 * 60 * 60);
            
            if (diffInHours < 24) {
                if (diffInHours < 1) {
                    const minutes = Math.floor((now - dateObj) / (1000 * 60));
                    return `${minutes} minute${minutes !== 1 ? 's' : ''} ago`;
                }
                return `${Math.floor(diffInHours)} hour${diffInHours !== 1 ? 's' : ''} ago`;
            }
            
            return dateObj.toLocaleString(undefined, {
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
        } catch (error) {
            console.error('Error formatting date:', error);
            return 'Invalid Date';
        }
    },

    startAutoRefresh() {
        // Clear any existing interval
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }

        // Refresh stats every 30 seconds
        this.refreshInterval = setInterval(async () => {
            try {
                const response = await api.get('/api/admin/stats');
                if (response.success) {
                    // Rerender the stats
                    this.renderStats(response.data, document.getElementById('adminContent'));
                }
            } catch (error) {
                console.error('Error refreshing stats:', error);
            }
        }, 30000);
    },

    cleanup() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    },

    renderChartSection(chartData) {
        if (!chartData) return '';
        
        return `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <!-- Activity Trend Chart -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
                    <div class="p-4">
                        <h3 class="text-lg font-semibold text-gray-700 mb-4">Activity Trend</h3>
                        <canvas id="activityTrendChart" height="200"></canvas>
                    </div>
                </div>

                <!-- User Distribution Chart -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
                    <div class="p-4">
                        <h3 class="text-lg font-semibold text-gray-700 mb-4">User Distribution</h3>
                        <canvas id="userDistributionChart" height="200"></canvas>
                    </div>
                </div>
            </div>
        `;
    },

    initializeCharts(chartData) {
        if (!chartData) return;

        // Activity Trend Chart
        const activityCtx = document.getElementById('activityTrendChart')?.getContext('2d');
        if (activityCtx) {
            new Chart(activityCtx, {
                type: 'line',
                data: {
                    labels: chartData.activityLabels || [],
                    datasets: [{
                        label: 'Articles',
                        data: chartData.articleData || [],
                        borderColor: 'rgb(59, 130, 246)',
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        tension: 0.4
                    }, {
                        label: 'Comments',
                        data: chartData.commentData || [],
                        borderColor: 'rgb(16, 185, 129)',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        // User Distribution Chart
        const distributionCtx = document.getElementById('userDistributionChart')?.getContext('2d');
        if (distributionCtx) {
            new Chart(distributionCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Active', 'Inactive', 'Admin'],
                    datasets: [{
                        data: [
                            chartData.userDistribution?.active || 0,
                            chartData.userDistribution?.inactive || 0,
                            chartData.userDistribution?.admin || 0
                        ],
                        backgroundColor: [
                            'rgb(16, 185, 129)',
                            'rgb(239, 68, 68)',
                            'rgb(139, 92, 246)'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }
    }
};