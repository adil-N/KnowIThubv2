// frontend/src/js/admin/superAdminPanel.js - Updated version
import { superAdmin } from './superAdmin.js';
import { superAdminStatsPanel } from './superAdminStatsPanel.js';
import { ui } from '../utils/ui.js';
import { api } from '../utils/api.js';
import { auth } from '../utils/auth.js';

// Make functions globally available
window.superAdmin = superAdmin;

export async function showSuperAdminPanel() {
    try {
        const superAdminContent = document.getElementById('superAdminContent');
        if (!superAdminContent) throw new Error('Required elements not found');
        
        const user = auth.user.get();
        if (!user?.user?.role || user.user.role !== 'super') {
            throw new Error('Not a super admin user');
        }

        // Render the main panel structure with tabs
        superAdminContent.innerHTML = `
            <div class="p-4">
                <h1 class="text-2xl font-bold mb-4">Super Admin Dashboard</h1>
                
                <!-- Tab Navigation -->
                <div class="border-b border-gray-200 mb-4">
                    <nav class="-mb-px flex space-x-8">
                        <button id="tab-stats" class="tab-button border-blue-500 text-blue-600 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                            Statistics Dashboard
                        </button>
                        <button id="tab-admin" class="tab-button border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
                            Administrator Management
                        </button>
                    </nav>
                </div>
                
                <!-- Tab Content -->
                <div id="tabContent" class="min-h-[600px]">
                    <!-- Content will be loaded here -->
                    <div class="flex items-center justify-center h-64">
                        <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
                    </div>
                </div>
            </div>
        `;

        // Initialize the panel and show the default tab
        await initializeSuperAdminPanel();
        return true;

    } catch (error) {
        console.error('Error in showSuperAdminPanel:', error);
        ui.showError(error.message);
        return false;
    }
}

async function initializeSuperAdminPanel() {
    try {
        // Set up tab switching
        const tabContent = document.getElementById('tabContent');
        const statsTab = document.getElementById('tab-stats');
        const adminTab = document.getElementById('tab-admin');
        
        if (!tabContent || !statsTab || !adminTab) {
            throw new Error('Required elements not found');
        }
        
        // Show statistics dashboard by default
        await showStatisticsTab();
        
        // Add event listeners for tab switching
        statsTab.addEventListener('click', async () => {
            setActiveTab('stats');
            await showStatisticsTab();
        });
        
        adminTab.addEventListener('click', async () => {
            setActiveTab('admin');
            await showAdminManagementTab();
        });
        
        // Attach event listeners for other functionality
        attachEventListeners();
    } catch (error) {
        console.error('Error initializing super admin panel:', error);
        ui.showError('Failed to initialize super admin panel');
    }
}

function setActiveTab(tabName) {
    const tabs = document.querySelectorAll('.tab-button');
    tabs.forEach(tab => {
        if (tab.id === `tab-${tabName}`) {
            tab.classList.add('border-blue-500', 'text-blue-600');
            tab.classList.remove('border-transparent', 'text-gray-500', 'hover:text-gray-700', 'hover:border-gray-300');
        } else {
            tab.classList.remove('border-blue-500', 'text-blue-600');
            tab.classList.add('border-transparent', 'text-gray-500', 'hover:text-gray-700', 'hover:border-gray-300');
        }
    });
}

async function showStatisticsTab() {
    const tabContent = document.getElementById('tabContent');
    if (!tabContent) return;
    
    // Clear previous content and show loading indicator
    tabContent.innerHTML = `
        <div class="flex items-center justify-center h-64">
            <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        </div>
    `;
    
    // Initialize the statistics dashboard
    await superAdminStatsPanel.initialize(tabContent);
}

async function showAdminManagementTab() {
    const tabContent = document.getElementById('tabContent');
    if (!tabContent) return;
    
    // Clear previous content and show loading indicator
    tabContent.innerHTML = `
        <div class="flex items-center justify-center h-64">
            <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        </div>
    `;
    
    try {
        // Load admin management content
        await loadAdminManagement(tabContent);
    } catch (error) {
        console.error('Error loading admin management tab:', error);
        tabContent.innerHTML = `
            <div class="p-4 bg-red-100 text-red-800 rounded-md">
                <p class="font-semibold">Error loading administrator management</p>
                <p>${error.message || 'Unknown error occurred'}</p>
            </div>
        `;
    }
}

async function loadAdminManagement(container) {
    try {
        ui.showLoading();
        const response = await api.get('/api/admin/super/admins');
        if (!response.success) throw new Error(response.message);

        const admins = response.data;
        container.innerHTML = `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="bg-white p-4 rounded shadow">
                    <h2 class="text-lg font-semibold mb-2">Administrator Management</h2>
                    <div id="adminStats">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <h3 class="text-sm font-medium text-gray-500">Total Admins</h3>
                                <p class="mt-1 text-2xl font-semibold text-gray-900">${admins.length}</p>
                            </div>
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <h3 class="text-sm font-medium text-gray-500">Active Admins</h3>
                                <p class="mt-1 text-2xl font-semibold text-gray-900">
                                    ${admins.filter(admin => admin.status === 'active').length}
                                </p>
                            </div>
                            <div class="bg-gray-50 p-4 rounded-lg">
                                <h3 class="text-sm font-medium text-gray-500">System Status</h3>
                                <p class="mt-1 text-2xl font-semibold text-green-600">Active</p>
                            </div>
                        </div>
                        <div class="mt-6">
                            <div class="flex justify-between items-center mb-4">
                                <h3 class="text-lg font-medium text-gray-900">Administrator List</h3>
                                <button onclick="superAdmin.handleCreateAdmin()" 
                                    class="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                                    Add Admin
                                </button>
                            </div>
                            <div class="overflow-x-auto">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Role</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        ${admins.map(admin => `
                                            <tr>
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <div class="text-sm font-medium text-gray-900">
                                                        ${admin.firstName} ${admin.lastName}
                                                    </div>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <div class="text-sm text-gray-500">${admin.email}</div>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                                        ${admin.role === 'super' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'}">
                                                        ${admin.role.toUpperCase()}
                                                    </span>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                                        ${admin.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                                                        ${admin.status.toUpperCase()}
                                                    </span>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <button onclick="superAdmin.handleEditAdmin('${admin._id}')" 
                                                        class="text-indigo-600 hover:text-indigo-900 mr-2">
                                                        Edit
                                                    </button>
                                                    ${admin.role !== 'super' ? `
                                                        <button onclick="superAdmin.handleResetPassword('${admin._id}')"
                                                            class="text-yellow-600 hover:text-yellow-900 mr-2">
                                                            Reset Password
                                                        </button>
                                                        <button onclick="superAdmin.handleDeleteAdmin('${admin._id}')"
                                                            class="text-red-600 hover:text-red-900">
                                                            Delete
                                                        </button>
                                                    ` : ''}
                                                </td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-white p-4 rounded shadow">
                    <h2 class="text-lg font-semibold mb-2">Recent Activity</h2>
                    <div id="adminActivity">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-md font-medium text-gray-700">Activity Log</h3>
                            <div class="flex space-x-2">
                                <input type="date" id="logStartDate" class="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm">
                                <input type="date" id="logEndDate" class="rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 text-sm">
                                <button id="filterLogs" class="px-2 py-1 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700">
                                    Filter
                                </button>
                                <button id="exportLogs" class="px-2 py-1 bg-green-600 text-white text-sm rounded-md hover:bg-green-700">
                                    Export
                                </button>
                            </div>
                        </div>
                        <div id="activityLogContainer">
                            Loading activity logs...
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Load activity logs
        await loadActivityLog();
        
    } catch (error) {
        console.error('Error loading statistics:', error);
        ui.showError('Failed to load admin statistics');
    } finally {
        ui.hideLoading();
    }
}

async function loadActivityLog() {
    try {
        const response = await api.get('/api/admin/super/logs');
        const adminActivity = document.getElementById('activityLogContainer');
        if (!adminActivity) return;

        if (response.success && response.data.length > 0) {
            adminActivity.innerHTML = `
                <div class="space-y-4 max-h-[600px] overflow-y-auto">
                    ${response.data.map(log => {
                        const admin = log.adminId || {};
                        return `
                            <div class="bg-gray-50 p-3 rounded-lg">
                                <div class="flex justify-between items-start">
                                    <div class="space-y-1">
                                        <p class="text-sm font-medium text-gray-900">${log.action}</p>
                                        <p class="text-xs text-gray-600">
                                            By ${admin.firstName} ${admin.lastName} (${admin.email})
                                        </p>
                                        ${log.details ? `
                                            <div class="text-xs text-gray-500">
                                                ${Object.entries(log.details)
                                                    .filter(([key]) => !['articleId', 'originalArticleId'].includes(key))
                                                    .map(([key, value]) => 
                                                        `<p><span class="font-medium">${key}:</span> ${
                                                            typeof value === 'object' ? JSON.stringify(value) : value
                                                        }</p>`
                                                    ).join('')}
                                            </div>
                                        ` : ''}
                                        ${log.formattedArticleId ? `
                                            <p class="text-xs text-green-600">Article ID: ${log.formattedArticleId}</p>
                                        ` : ''}
                                    </div>
                                    <span class="text-xs text-gray-500">
                                        ${new Date(log.timestamp).toLocaleString()}
                                    </span>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            `;
        } else {
            adminActivity.innerHTML = '<p class="text-gray-500 text-center py-4">No activity logs found</p>';
        }
    } catch (error) {
        console.error('Error loading activity log:', error);
        const adminActivity = document.getElementById('activityLogContainer');
        if (adminActivity) {
            adminActivity.innerHTML = '<p class="text-red-500 text-center py-4">Error loading activity logs</p>';
        }
    }
}

function attachEventListeners() {
    // Filter logs button
    document.getElementById('filterLogs')?.addEventListener('click', () => {
        const startDate = document.getElementById('logStartDate').value;
        const endDate = document.getElementById('logEndDate').value;
        if (startDate && endDate) {
            superAdmin.handleFilterLogs(startDate, endDate);
        }
    });
    
    // Export logs button
    document.getElementById('exportLogs')?.addEventListener('click', () => {
        superAdmin.handleExportLogs();
    });
}

// Make loadActivityLog globally available for the superAdmin module
window.loadActivityLog = loadActivityLog;
