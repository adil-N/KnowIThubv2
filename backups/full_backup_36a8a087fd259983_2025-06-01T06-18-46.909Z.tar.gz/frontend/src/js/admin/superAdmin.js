// frontend/src/js/admin/superAdmin.js
import { api } from '../utils/api.js';
import { ui } from '../utils/ui.js';
import { auth } from '../utils/auth.js';

export const superAdmin = {
    async handleEditAdmin(adminId) {
        try {
            const response = await api.get(`/api/admin/super/admins/${adminId}`);
            if (!response.success) throw new Error(response.message);
            
            this.showEditModal(response.data);
        } catch (error) {
            ui.showError('Failed to load admin details');
        }
    },

    showEditModal(admin) {
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-white p-6 rounded-lg max-w-md w-full">
                <h3 class="text-lg font-bold mb-4">Edit Administrator</h3>
                <form id="editAdminForm" class="space-y-4">
                    <input type="hidden" id="adminId" value="${admin._id}">
                    <div>
                        <label class="block text-sm font-medium">First Name</label>
                        <input type="text" id="editFirstName" value="${admin.firstName}" required
                            class="mt-1 w-full rounded border p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-medium">Last Name</label>
                        <input type="text" id="editLastName" value="${admin.lastName}" required
                            class="mt-1 w-full rounded border p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-medium">Status</label>
                        <select id="editStatus" class="mt-1 w-full rounded border p-2">
                            <option value="active" ${admin.status === 'active' ? 'selected' : ''}>Active</option>
                            <option value="inactive" ${admin.status === 'inactive' ? 'selected' : ''}>Inactive</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium">Role</label>
                        <select id="editRole" class="mt-1 w-full rounded border p-2"
                            ${admin.role === 'super' ? 'disabled' : ''}>
                            <option value="admin" ${admin.role === 'admin' ? 'selected' : ''}>Admin</option>
                            <option value="super" ${admin.role === 'super' ? 'selected' : ''}>Super Admin</option>
                        </select>
                    </div>
                    <div class="flex justify-end space-x-2 pt-4">
                        <button type="button" onclick="this.closest('.fixed').remove()"
                            class="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300">Cancel</button>
                        <button type="submit"
                            class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Save Changes</button>
                    </div>
                </form>
            </div>
        `;

        document.body.appendChild(modal);
        document.getElementById('editAdminForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            await this.handleSaveAdminChanges(modal);
        });
    },

    
    async handleSaveAdminChanges(modal) {
        try {
            ui.showLoading();
            const adminId = document.getElementById('adminId').value;
            const formData = {
                firstName: document.getElementById('editFirstName').value.trim(),
                lastName: document.getElementById('editLastName').value.trim(),
                status: document.getElementById('editStatus').value,
                role: document.getElementById('editRole').value
            };
    
            // Validate form data
            if (!formData.firstName || !formData.lastName) {
                throw new Error('First name and last name are required');
            }
    
            // Log the update attempt
            console.log('Attempting to update admin:', {
                adminId,
                formData
            });
    
            const response = await api.put(`/api/admin/super/admins/${adminId}`, formData);
            
            console.log('Server response:', response);
    
            if (!response.success) {
                throw new Error(response.message || 'Failed to update administrator');
            }
    
            // Success handling
            modal.remove();
            ui.showError('Administrator updated successfully', 'success');
            
            // Reload admin panel
            try {
                await this.reloadAdminPanel();
            } catch (reloadError) {
                console.error('Error reloading admin panel:', reloadError);
                // Force a hard refresh of the admin panel
                window.location.hash = '#admin';
            }
        } catch (error) {
            console.error('Error in handleSaveAdminChanges:', error);
            ui.showError(error.message || 'Failed to update administrator');
        } finally {
            ui.hideLoading();
        }
    },




// Update these methods in superAdmin.js

// In superAdmin.js, update the handleResetPassword function

async handleResetPassword(adminId) {
    if (!confirm('Reset password? Administrator will need to change it on next login.')) return;

    try {
        ui.showLoading();

        // Make a single API call
        const endpoint = `/api/admin/super/admins/${adminId}/reset-password`;
        const response = await api.post(endpoint, {});

        console.log('Password reset response:', {
            success: response.success,
            hasTemporaryPassword: !!response.data?.temporaryPassword
        });

        if (!response.success || !response.data?.temporaryPassword) {
            throw new Error(response.message || 'Failed to reset password');
        }

        // Store the email for the reset flow
        if (response.data.email) {
            localStorage.setItem('resetEmail', response.data.email);
        }

        // Show the temporary password
        await this.showResetPasswordModal(response.data.temporaryPassword, adminId);
        ui.showError('Password has been reset successfully', 'success');

    } catch (error) {
        console.error('Password reset error:', error);
        ui.showError(error.message || 'Failed to reset password');
    } finally {
        ui.hideLoading();
    }
},

showResetPasswordModal(temporaryPassword, adminId) {
    return new Promise((resolve) => {
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-white p-6 rounded-lg max-w-md w-full">
                <h3 class="text-lg font-bold mb-4">Password Reset Successful</h3>
                <p class="mb-2">Temporary password for Admin ID: ${adminId}</p>
                <div class="relative mb-4">
                    <div class="flex items-center space-x-0">
                        <input type="text" 
                            value="${temporaryPassword}" 
                            readonly 
                            id="tempPasswordField"
                            class="flex-1 bg-gray-100 p-3 rounded-l font-mono">
                        <button id="copyPasswordBtn"
                            type="button"
                            class="px-4 py-3 bg-blue-500 text-white rounded-r hover:bg-blue-600 focus:outline-none">
                            Copy
                        </button>
                    </div>
                    <span id="copyFeedback" class="hidden text-green-600 text-sm mt-1">
                        Password copied!
                    </span>
                </div>
                <div class="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
                    <div class="flex">
                        <div class="flex-1">
                            <p class="text-sm text-yellow-700">
                                <strong>Important Notes:</strong>
                                <ul class="list-disc ml-4 mt-2">
                                    <li>This password is temporary and must be changed on first login</li>
                                    <li>Communicate this password securely to the administrator</li>
                                    <li>The password will only be shown once in this window</li>
                                </ul>
                            </p>
                        </div>
                    </div>
                </div>
                <button id="closeModalBtn" 
                    type="button"
                    class="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 focus:outline-none">
                    Close
                </button>
            </div>
        `;

        document.body.appendChild(modal);

        // Set up copy functionality
        const copyButton = modal.querySelector('#copyPasswordBtn');
        const passwordField = modal.querySelector('#tempPasswordField');
        const copyFeedback = modal.querySelector('#copyFeedback');
        const closeButton = modal.querySelector('#closeModalBtn');

        copyButton.addEventListener('click', () => {
            try {
                // Select the text
                passwordField.select();
                passwordField.setSelectionRange(0, 99999); // For mobile devices
                
                // Copy to clipboard
                document.execCommand('copy');
                // Or use clipboard API as fallback
                if (!document.execCommand('copy')) {
                    navigator.clipboard.writeText(temporaryPassword);
                }
                
                // Show feedback
                copyFeedback.classList.remove('hidden');
                setTimeout(() => copyFeedback.classList.add('hidden'), 2000);
                
                // Deselect
                window.getSelection().removeAllRanges();
                
                ui.showError('Password copied to clipboard!', 'success');
            } catch (error) {
                console.error('Copy failed:', error);
                ui.showError('Failed to copy password. Please copy manually.');
            }
        });

        closeButton.addEventListener('click', () => {
            modal.remove();
            resolve();
        });
    });
},




// Helper method to check auth status
checkAuthStatus() {
    const token = auth.getToken();
    if (!token) {
        window.location.hash = '#login';
        return false;
    }
    return true;
},

initialize() {
    if (!this.checkAuthStatus() || !this.isSuperAdmin()) {
        window.location.hash = '#login';
        return;
    }
   
},

    async reloadAdminPanel() {
        try {
            const loadStatistics = window.loadStatistics;
            if (typeof loadStatistics === 'function') {
                await loadStatistics();
            } else {
                window.location.hash = '#admin';
            }
        } catch (error) {
            console.error('Error reloading admin panel:', error);
            window.location.hash = '#admin';
        }
    },

    async handleDeleteAdmin(adminId) {
        if (!confirm('Delete this administrator? This cannot be undone.')) return;
        
        try {
            ui.showLoading();
            const response = await api.delete(`/api/admin/super/admins/${adminId}`);
            
            if (response.success) {
                ui.showError('Administrator deleted successfully', 'success');
                await window.loadStatistics();
            }
        } catch (error) {
            ui.showError('Failed to delete administrator');
        } finally {
            ui.hideLoading();
        }
    },

    initialize() {
        if (!this.isSuperAdmin()) {
            window.location.hash = '#admin';
            return;
        }
    },

    isSuperAdmin() {
        const user = auth.user.get();
        return user?.user?.role === 'super';
    },

    handleFilterLogs(startDate, endDate) {
        if (startDate && endDate) {
            window.loadActivityLog(startDate, endDate);
        }
    },

    handleExportLogs() {
        const startDate = document.getElementById('logStartDate')?.value;
        const endDate = document.getElementById('logEndDate')?.value;
        
        if (startDate && endDate) {
            window.location.href = `/api/admin/super/logs/export?start=${startDate}&end=${endDate}`;
        } else {
            ui.showError('Please select a date range to export');
        }
    }
};

// Make functions globally available
window.superAdmin = superAdmin;