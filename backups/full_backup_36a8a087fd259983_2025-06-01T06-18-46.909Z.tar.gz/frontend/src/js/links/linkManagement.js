// frontend/src/js/links/linkManagement.js
import { api } from '../utils/api.js';
import { ui } from '../utils/ui.js';
import { auth } from '../utils/auth.js';

export const linkManagement = {
    isSubmitting: false,
    initialized: false,
    categories: new Set(['General']),

    async initialize() {
        if (!auth.isAuthenticated()) {
            console.log('User not authenticated, skipping link management initialization');
            const linksSection = document.getElementById('linksSection');
            if (linksSection) {
                linksSection.classList.add('hidden');
            }
            return false;
        }
        
        if (this.initialized && window.location.hash !== '#links') {
            return true;
        }
    
        try {
            // Only proceed if we're on the links page
            if (window.location.hash !== '#links') {
                const linksSection = document.getElementById('linksSection');
                if (linksSection) {
                    linksSection.classList.add('hidden', 'absolute');
                    linksSection.classList.remove('relative');
                }
                return false;
            }
            
            const linksSection = document.getElementById('linksSection');
            if (linksSection) {
                linksSection.classList.remove('hidden', 'absolute');
                linksSection.classList.add('relative');
            }
            
            await this.fetchCategories();
            this.createLinksPageStructure();
            this.attachEventListeners();
            this.initialized = true;
            return true;
        } catch (error) {
            console.error('Error initializing link management:', error);
            return false;
        }
    },

    async fetchCategories() {
        try {
            console.log('Fetching categories...');
            const response = await api.get('/api/links/categories');
            console.log('Categories response:', response);
            
            if (response.success && Array.isArray(response.data)) {
                // Create new Set with 'General' and all valid categories
                this.categories = new Set([
                    'General', 
                    ...response.data.filter(category => category && category.trim())
                ]);
                console.log('Updated categories:', Array.from(this.categories));
            } else {
                console.warn('Invalid categories response:', response);
                this.categories = new Set(['General']);
            }
        } catch (error) {
            console.error('Error fetching categories:', error);
            this.categories = new Set(['General']);
        } finally {
            this.updateCategorySelect();
        }
    },

    updateCategorySelect() {
        const select = document.getElementById('linkCategory');
        if (!select) {
            console.warn('Category select element not found');
            return;
        }
    
        const currentValue = select.value;
        select.innerHTML = '';
    
        // Sort categories with 'General' first, then alphabetically
        const sortedCategories = Array.from(this.categories)
            .filter(Boolean)
            .sort((a, b) => {
                if (a === 'General') return -1;
                if (b === 'General') return 1;
                return a.localeCompare(b);
            });
    
        sortedCategories.forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            select.appendChild(option);
        });
    
        // Restore selection if valid
        if (currentValue && this.categories.has(currentValue)) {
            select.value = currentValue;
        }
    },
    attachEventListeners() {
        // Add Link button
        const addLinkBtn = document.getElementById('addLinkBtn');
        if (addLinkBtn) {
            addLinkBtn.addEventListener('click', () => {
                const form = document.getElementById('addLinkForm');
                if (form) {
                    form.reset();
                    form.removeAttribute('data-edit-id');
                    const modalTitle = document.querySelector('#linkModal h3');
                    if (modalTitle) modalTitle.textContent = 'Add New Link';
                }
                this.showModal();
            });
        }
    
        // Link form submission
        const linkForm = document.getElementById('addLinkForm');
        if (linkForm) {
            console.log('Attaching submit event to form');
            linkForm.addEventListener('submit', (e) => {
                e.preventDefault();
                console.log('Form submitted:', e.target);
                this.handleSubmit(e);
            });
        } else {
            console.error('Link form not found in DOM');
        }
    
        // Close modal
        const closeModalBtn = document.getElementById('closeLinkModal');
        if (closeModalBtn) {
            closeModalBtn.addEventListener('click', () => this.hideModal());
        }
     // New category button - Add this
     const newCategoryBtn = document.getElementById('newCategoryBtn');
     if (newCategoryBtn) {
         newCategoryBtn.addEventListener('click', () => {
             this.handleNewCategory();
         });
     } else {
         console.error('New category button not found');
     }
        // Link container event delegation
        const linksContainer = document.getElementById('linksContainer');
        if (linksContainer) {
            linksContainer.addEventListener('click', async (e) => {
                const target = e.target;
                const button = target.closest('button');
                if (!button) return;
    
                e.preventDefault();
                e.stopPropagation();
    
                const linkId = button.getAttribute('data-link-id');
                
                if (button.classList.contains('edit-button') && linkId) {
                    console.log('Edit button clicked:', linkId);
                    await this.editLink(linkId);
                    return;
                }
    
                if (button.classList.contains('delete-button') && linkId) {
                    await this.deleteLink(linkId);
                    return;
                }
    
                // In the linksContainer event listener
const url = button.getAttribute('data-url');

if (button.classList.contains('copy-link') && url) {
    try {
        await navigator.clipboard.writeText(url);
        ui.showSuccess('Path copied to clipboard');
    } catch (error) {
        console.error('Error copying to clipboard:', error);
        ui.showError('Failed to copy path');
    }
    return;
}

if (button.classList.contains('open-link') && url) {
    await this.openLink(url);
    return;
}
            });
        }
    },

    async openLink(url) {
        try {
            url = decodeURIComponent(url);
            console.log('Opening URL:', url);
    
            // Handle network shares and local paths
            if (url.startsWith('\\\\') || url.startsWith('//') || /^[a-zA-Z]:[\\\/]/i.test(url)) {
                try {
                    // Try to open using Windows Explorer protocol
                    const cleanPath = url.replace(/\\/g, '/');
                    
                    // Try to launch Windows Explorer directly
                    if (url.startsWith('\\\\')) {
                        // For network paths
                        window.location.href = `file:${cleanPath}`;
                    } else {
                        // For local paths
                        window.location.href = `file:///${cleanPath}`;
                    }
    
                    // Create a button for copying as fallback
                    const copyButton = document.createElement('button');
                    copyButton.textContent = 'Copy Path';
                    copyButton.className = 'px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 ml-2';
                    copyButton.onclick = async () => {
                        try {
                            await navigator.clipboard.writeText(url);
                            ui.showSuccess('Path copied to clipboard');
                        } catch (err) {
                            ui.showError('Failed to copy path');
                        }
                    };
    
                    // Show info message with copy button
                    ui.showError('If Explorer didn\'t open, click here to copy the path', {
                        timeout: 5000,
                        action: copyButton
                    });
    
                } catch (explorerError) {
                    console.error('Failed to open in Explorer:', explorerError);
                    // Try copying to clipboard as fallback
                    try {
                        await navigator.clipboard.writeText(url);
                        ui.showSuccess('Path copied to clipboard');
                    } catch (clipboardError) {
                        ui.showError('Failed to open path and copy to clipboard');
                    }
                }
                return;
            }
    
            // Handle URLs with protocols (http://, https://, etc.)
            if (/^[a-z]+:\/\//i.test(url)) {
                window.open(url, '_blank');
                return;
            }
    
            // Handle regular web URLs (add http://)
            window.open(`http://${url}`, '_blank');
            
        } catch (error) {
            console.error('Error opening link:', error);
            ui.showError('Failed to open path. Click to copy instead', {
                timeout: 5000,
                action: {
                    text: 'Copy Path',
                    onClick: async () => {
                        try {
                            await navigator.clipboard.writeText(url);
                            ui.showSuccess('Path copied to clipboard');
                        } catch (err) {
                            ui.showError('Failed to copy path');
                        }
                    }
                }
            });
        }
    },

    async editLink(linkId) {
        try {
            ui.showLoading();
            console.log('Loading link for editing:', linkId);
            
            const response = await api.get(`/api/links/${linkId}`);
            console.log('Edit link response:', response);
            
            if (!response.success || !response.data) {
                throw new Error('Failed to load link details');
            }
    
            const link = response.data;
            
            // Get form elements
            const form = document.getElementById('addLinkForm');
            const modal = document.getElementById('linkModal');
            const nameInput = document.getElementById('linkName');
            const urlInput = document.getElementById('linkUrl');
            const descriptionInput = document.getElementById('linkDescription');
            const categorySelect = document.getElementById('linkCategory');
            
            if (!form || !modal || !nameInput || !urlInput || !descriptionInput || !categorySelect) {
                throw new Error('Required form elements not found');
            }
    
            // Update form fields with link data
            nameInput.value = link.name || '';
            urlInput.value = link.url || '';
            descriptionInput.value = link.description || '';
            
            // Ensure the category exists in the select options
            const category = link.category || 'General';
            if (!this.categories.has(category)) {
                console.log('Adding missing category:', category);
                this.categories.add(category);
                this.updateCategorySelect();
            }
            
            // Set the category
            categorySelect.value = category;
    
            // Set form to edit mode
            form.setAttribute('data-edit-id', linkId);
    
            // Update modal title
            const modalTitle = modal.querySelector('h3');
            if (modalTitle) {
                modalTitle.textContent = 'Edit Link';
            }
    
            // Show the modal
            modal.classList.remove('hidden');
            
            console.log('Link loaded for editing:', {
                name: nameInput.value,
                url: urlInput.value,
                description: descriptionInput.value,
                category: categorySelect.value
            });
    
        } catch (error) {
            console.error('Error editing link:', error);
            ui.showError('Error loading link details');
        } finally {
            ui.hideLoading();
        }
    },

    async handleSubmit(e) {
        e.preventDefault();
        if (this.isSubmitting) return;
        this.isSubmitting = true;
    
        try {
            ui.showLoading();
            const form = e.target;
            const linkId = form.getAttribute('data-edit-id');
            
            // Get the category value
            const categorySelect = form.querySelector('#linkCategory');
            const categoryValue = categorySelect ? categorySelect.value.trim() : 'General';
            
            const linkData = {
                name: form.querySelector('#linkName').value.trim(),
                url: form.querySelector('#linkUrl').value.trim(),
                description: form.querySelector('#linkDescription').value.trim(),
                category: categoryValue
            };
    
            console.log('Submitting link data:', linkData); // Debug log
    
            let response;
            if (linkId) {
                response = await api.put(`/api/links/${linkId}`, linkData);
                console.log('Update response:', response); // Debug log
            } else {
                response = await api.post('/api/links', linkData);
            }
    
            if (response.success) {
                ui.showSuccess(linkId ? 'Link updated successfully' : 'Link added successfully');
                this.hideModal();
                await this.loadLinks();
                form.removeAttribute('data-edit-id');
            } else {
                throw new Error(response.message || 'Failed to save link');
            }
        } catch (error) {
            console.error('Error saving link:', error);
            ui.showError(error.message || 'Error saving link');
        } finally {
            this.isSubmitting = false;
            ui.hideLoading();
        }
    },

    

    async showModal() {
        const modal = document.getElementById('linkModal');
        if (modal) {
            const form = document.getElementById('addLinkForm');
            
            // Fetch categories before showing modal
            await this.fetchCategories();
            
            modal.classList.remove('hidden');
        }
    },

    hideModal() {
        const modal = document.getElementById('linkModal');
        const form = document.getElementById('linkForm');
        
        if (modal) {
            modal.classList.add('hidden');
            
            // Clean up form
            if (form) {
                form.reset();
                form.removeAttribute('data-edit-id');
                
                // Reset modal title
                const modalTitle = modal.querySelector('h3');
                if (modalTitle) {
                    modalTitle.textContent = 'Add New Link';
                }
            }
        }
    },
    createLinksPageStructure() {
        const linksSection = document.getElementById('linksSection');
        if (!linksSection) return;
    
        linksSection.innerHTML = `
            <div>
                <div class="flex justify-between items-center mb-4">
                    <h1 class="text-3xl font-bold text-gray-900">Quick Links</h1>
                    <button id="addLinkBtn" 
                            class="inline-flex items-center px-2 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-all">
                        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                        </svg>
                        Add Link
                    </button>
                </div>
    
                <div id="categoryTabs" class="flex flex-wrap gap-2 mb-6">
                    <!-- Categories will be inserted here -->
                </div>
    
                <div id="linksContainer" class="space-y-4">
                    <!-- Links will be inserted here -->
                </div>
    
                <!-- Modal -->
                <div id="linkModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
                    <div class="flex items-center justify-center min-h-screen px-4">
                        <div class="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
                            <div class="flex justify-between items-center mb-4">
                                <h3 class="text-lg font-semibold text-gray-900">Add New Link</h3>
                                <button id="closeLinkModal" class="text-gray-400 hover:text-gray-500">
                                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                                    </svg>
                                </button>
                            </div>
                            <form id="addLinkForm" class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Name</label>
                                    <input type="text" id="linkName" required
                                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">URL or Path</label>
                                    <input type="text" id="linkUrl" required
                                           class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                    <p class="mt-1 text-sm text-gray-500">Can be a web URL, network path, or file path</p>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Description</label>
                                    <textarea id="linkDescription" rows="3"
                                              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"></textarea>
                                </div>
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Category</label>
                                    <div class="flex gap-2">
                                        <select id="linkCategory" 
                                                class="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500">
                                            <option value="General">General</option>
                                        </select>
                                        <button type="button" id="newCategoryBtn"
                                                class="px-3 py-2 bg-gray-100 text-gray-600 rounded-md hover:bg-gray-200 transition-all">
                                            New
                                        </button>
                                    </div>
                                </div>
                                <div class="flex justify-end pt-4">
                                    <button type="submit" 
                                            class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-all">
                                        Save Link
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },
    // Find this function in linkManagement.js
    // Update this function in linkManagement.js
renderLinkItem(link) {
    const escapedUrl = link.url.replace(/"/g, '&quot;');
    const isLocalPath = link.url.startsWith('\\\\') || link.url.startsWith('//') || /^[a-zA-Z]:[\\\/]/i.test(link.url);
    const userData = auth.user.get();
    const canEdit = userData?.user?.role === 'admin' || userData?.user?.role === 'super' || 
                   link.author === userData?.user?._id;

    return `
        <div class="group p-4 hover:bg-gray-50 transition-all bg-white rounded-lg shadow-sm" data-link-id="${link._id}">
            <div class="flex flex-col">
                <!-- Title and Action Buttons Row -->
                <div class="flex items-start justify-between mb-2">
                    <div class="flex-grow">
                        <div class="flex items-center gap-3">
                            <span class="text-lg font-medium text-gray-900">${link.name}</span>
                            ${isLocalPath ? `
                                <button 
                                    class="copy-link inline-flex items-center px-3 py-1 bg-gray-50 text-gray-600 rounded-md hover:bg-gray-100 transition-colors"
                                    data-url="${escapedUrl}"
                                >
                                    <svg class="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                              d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"/>
                                    </svg>
                                    Copy Path
                                </button>
                            ` : `
                                <button 
                                    class="open-link inline-flex items-center px-3 py-1 bg-blue-50 text-blue-600 rounded-md hover:bg-blue-100 transition-colors"
                                    data-url="${escapedUrl}"
                                >
                                    <svg class="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                              d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                                    </svg>
                                    Open Link
                                </button>
                            `}
                        </div>
                    </div>
                </div>

                <!-- URL Row -->
                ${link.url ? `
                    <p class="text-sm text-gray-500 mb-2 break-all">${escapedUrl}</p>
                ` : ''}

                <!-- Description Row -->
                ${link.description ? `
                    <div class="link-description-container">
                        <p class="text-gray-600 whitespace-pre-wrap break-words max-h-24 overflow-y-auto">${link.description}</p>
                    </div>
                ` : ''}

                <!-- Actions Row -->
                ${canEdit ? `
                    <div class="flex gap-2 mt-3">
                        <button class="edit-button px-2 py-1 text-blue-600 hover:bg-blue-50 rounded flex items-center"
                                data-link-id="${link._id}">
                            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                      d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                            </svg>
                            Edit
                        </button>
                        <button class="delete-button px-2 py-1 text-red-600 hover:bg-red-50 rounded flex items-center"
                                data-link-id="${link._id}">
                            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                                      d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                            </svg>
                            Delete
                        </button>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
},
    

    groupLinksByCategory(links) {
        return links.reduce((acc, link) => {
            const category = link.category || 'General';
            if (!acc[category]) {
                acc[category] = [];
            }
            acc[category].push(link);
            return acc;
        }, {});
    },

    renderLinks(links) {
        const groupedLinks = this.groupLinksByCategory(links);
        const linksContainer = document.getElementById('linksContainer');
        const categoryTabs = document.getElementById('categoryTabs');
        
        if (!linksContainer || !categoryTabs) return;

       // ... (previous code from Part 4) ...
        
        // Clear existing content
        linksContainer.innerHTML = '';
        categoryTabs.innerHTML = '';

        // Create category tabs
        const categories = Object.keys(groupedLinks).sort();
        categoryTabs.innerHTML = categories.map(category => `
            <button class="category-tab px-4 py-2 rounded-md text-sm font-medium transition-colors
                           ${category === 'General' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}"
                    data-category="${category}">
                ${category}
                <span class="ml-2 bg-white bg-opacity-20 px-2 py-0.5 rounded-full text-xs">
                    ${groupedLinks[category].length}
                </span>
            </button>
        `).join('');

        // Add click handlers to category tabs
        categoryTabs.querySelectorAll('.category-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                // Update active state of tabs
                categoryTabs.querySelectorAll('.category-tab').forEach(t => {
                    t.classList.remove('bg-blue-600', 'text-white');
                    t.classList.add('bg-gray-100', 'text-gray-700', 'hover:bg-gray-200');
                });
                e.target.classList.remove('bg-gray-100', 'text-gray-700', 'hover:bg-gray-200');
                e.target.classList.add('bg-blue-600', 'text-white');

                // Show links for selected category
                this.showCategoryLinks(groupedLinks, e.target.dataset.category);
            });
        });

        // Show initial category (General or first available)
        const initialCategory = groupedLinks['General'] ? 'General' : categories[0];
        this.showCategoryLinks(groupedLinks, initialCategory);
    },

    showCategoryLinks(groupedLinks, category) {
        const linksContainer = document.getElementById('linksContainer');
        if (!linksContainer) return;

        const links = groupedLinks[category] || [];
        
        if (links.length === 0) {
            linksContainer.innerHTML = `
                <div class="text-center py-8 text-gray-500">
                    No links found in this category
                </div>
            `;
            return;
        }

        linksContainer.innerHTML = `
            <div class="bg-white rounded-lg shadow divide-y">
                ${links.map(link => this.renderLinkItem(link)).join('')}
            </div>
        `;
    },

    // In linkManagement.js - Update the addNewCategory function
async addNewCategory(categoryName) {
    try {
        const response = await api.post('/api/links/categories', { 
            category: categoryName 
        });
        
        // Handle both success cases (new category or existing)
        if (response.success) {
            const category = response.data || categoryName;
            
            // Add to local categories set if not already present
            if (!this.categories.has(category)) {
                this.categories.add(category);
                this.updateCategorySelect();
            }
            
            return true;
        }
        
        return false;
    } catch (error) {
        console.error('Error adding category:', error);
        ui.showError(error.message || 'Failed to add category');
        return false;
    }
},

// Update the handleNewCategory function
async handleNewCategory() {
    try {
        const categoryName = prompt('Enter new category name:');
        if (!categoryName?.trim()) return false;

        const newCategory = categoryName.trim();
        
        // Check if category already exists locally
        if (this.categories.has(newCategory)) {
            ui.showSuccess('Category already exists');
            return true;
        }
        
        ui.showLoading();
        const success = await this.addNewCategory(newCategory);
        
        if (success) {
            // Update select element
            const select = document.getElementById('linkCategory');
            if (select) {
                select.value = newCategory;
            }
            ui.showSuccess('Category added successfully');
            return true;
        } else {
            ui.showError('Failed to add category');
            return false;
        }
    } catch (error) {
        console.error('Error handling new category:', error);
        ui.showError('Failed to add category');
        return false;
    } finally {
        ui.hideLoading();
    }
},


    
    // Add this helper function to check if a category exists
    async checkCategoryExists(categoryName) {
        try {
            const response = await api.get('/api/links/categories');
            if (response.success && Array.isArray(response.data)) {
                return response.data.includes(categoryName);
            }
            return false;
        } catch (error) {
            console.error('Error checking category:', error);
            return false;
        }
    },
    async loadLinks() {
        if (!auth.isAuthenticated()) {
            console.log('User not authenticated, cannot load links');
            window.location.hash = '#login';
            return;
        }

        try {
            ui.showLoading();
            const response = await api.get('/api/links');
            
            if (response.success) {
                this.renderLinks(response.data);
            } else {
                ui.showError('Failed to load links');
            }
        } catch (error) {
            console.error('Error loading links:', error);
            if (error.status === 401) {
                window.location.hash = '#login';
            } else {
                ui.showError('Error loading links');
            }
        } finally {
            ui.hideLoading();
        }
    },

handleLinkClick(event, url) {
    event.preventDefault();
    event.stopPropagation();  // Add this to prevent event bubbling

    try {
        // Clean the URL (remove any escaped characters)
        url = decodeURIComponent(url);
        console.log('Processing URL:', url);  // Debug log

        // Network share path (e.g., \\server\share)
        if (url.startsWith('\\')) {
            console.log('Detected network share:', url);
            // Use the file protocol with the correct number of slashes
            const formattedUrl = 'file:' + url.replace(/\\/g, '/');
            window.location.href = formattedUrl;
            return;
        }

        // Local file path (e.g., C:\ or D:\)
        if (url.match(/^[a-zA-Z]:[\\\/]/)) {
            console.log('Detected local file path:', url);
            const formattedUrl = 'file:///' + url.replace(/\\/g, '/');
            window.location.href = formattedUrl;
            return;
        }

        // Already has a protocol (http://, https://, file://)
        if (url.match(/^[a-z]+:\/\//i)) {
            window.open(url, '_blank');
            return;
        }

        // No protocol - assume http
        window.open('http://' + url, '_blank');
    } catch (error) {
        console.error('Error opening link:', error);
        ui.showError('Error opening link');
    }
},


// Update the handleAddLink function to handle both adding and editing
async handleAddLink(e) {
    e.preventDefault();
    if (this.isSubmitting) return;
    this.isSubmitting = true;

    try {
        ui.showLoading();
        const form = e.target;
        const linkId = form.dataset.linkId;  // Check if we're editing
        
        let url = form.querySelector('#linkUrl').value.trim();
        
        // Format URL based on type
        if (url.startsWith('\\')) {
            // Network share - keep as is
            url = url;
        } else if (url.match(/^[a-zA-Z]:[\\\/]/)) {
            // Local file path - normalize backslashes
            url = url.replace(/\\/g, '\\\\');
        } else if (!url.match(/^[a-z]+:\/\//i)) {
            // If no protocol specified and not a file path, add http://
            url = 'http://' + url;
        }

        const linkData = {
            name: form.querySelector('#linkName').value.trim(),
            url: url,
            description: form.querySelector('#linkDescription').value.trim(),
            category: form.querySelector('#linkCategory').value.trim() || 'General'
        };

        let response;
        if (linkId) {
            // Update existing link
            response = await api.put(`/api/links/${linkId}`, linkData);
        } else {
            // Create new link
            response = await api.post('/api/links', linkData);
        }
            
        if (response.success) {
            ui.showSuccess(linkId ? 'Link updated successfully' : 'Link added successfully');
            this.hideModal();
            await this.loadLinks();
            
            // Clear the form's linkId
            form.dataset.linkId = '';
        } else {
            ui.showError(response.message || 'Failed to save link');
        }
    } catch (error) {
        console.error('Error saving link:', error);
        ui.showError(error.message || 'Error saving link');
    } finally {
        this.isSubmitting = false;
        ui.hideLoading();
    }
},

   

    async deleteLink(linkId) {
        if (!confirm('Are you sure you want to delete this link?')) return;
        
        try {
            ui.showLoading();
            const response = await api.delete(`/api/links/${linkId}`);
            
            if (response.success) {
                ui.showSuccess('Link deleted successfully');
                await this.loadLinks();
            } else {
                ui.showError(response.message || 'Failed to delete link');
            }
        } catch (error) {
            console.error('Error deleting link:', error);
            ui.showError('Error deleting link');
        } finally {
            ui.hideLoading();
        }
    }
};
// Make linkManagement available globally for event handlers
window.linkManagement = linkManagement;

