// frontend/src/js/auth/login.js
import { api } from '../utils/api.js';
import { auth } from '../utils/auth.js';
import { ui } from '../utils/ui.js';
import { events } from '../utils/events.js';

export const login = {
    initialize() {
        this.bindLoginForm();
        console.log('Login module initialized');
    },

    bindLoginForm() {
        const form = document.querySelector('#loginForm form') || document.getElementById('loginFormElement');
        if (form) {
            form.addEventListener('submit', this.handleLogin.bind(this));
            console.log('Login form handler bound to:', form);
        } else {
            console.warn('Login form element not found');
        }
    },

    async handleLogin(event) {
        event.preventDefault();
        console.log('=== Login Attempt Started ===');
        
        const form = event.target;
        const emailInput = form.querySelector('input[type="email"]') || form.querySelector('#loginEmail');
        const passwordInput = form.querySelector('input[type="password"]') || form.querySelector('#loginPassword');
        const errorDiv = document.getElementById('loginError');
        
        // Clear previous errors
        if (errorDiv) {
            errorDiv.classList.add('hidden');
            errorDiv.textContent = '';
        }
    
        try {
            ui.showLoading();
            
            // Validate inputs
            if (!emailInput?.value || !passwordInput?.value) {
                throw new Error('Email and password are required');
            }
    
            const email = emailInput.value.trim();
            const password = passwordInput.value;
    
            console.log('Making login request for:', { email });
            
            const response = await api.post('/api/users/login', { email, password });
            console.log('Login response received:', { 
                success: response.success,
                hasData: !!response.data,
                passwordResetRequired: response.data?.user?.passwordResetRequired
            });
    
            if (!response.success || !response.data || !response.data.token) {
                throw new Error(response.message || 'Invalid login response');
            }
    
            const userData = response.data;
            
            // Explicitly handle password reset case
            if (userData.user?.passwordResetRequired === true) {
                console.log('Password reset still required, redirecting to force change');
                
                // Set temporary auth data
                const tempAuthSet = auth.tempAuth.set({
                    token: userData.token,
                    user: {
                        ...userData.user,
                        passwordResetRequired: true
                    }
                });
                
                // Store email for password reset process
                localStorage.setItem('resetEmail', userData.user.email);
                
                // Clear any existing user data
                auth.user.clear();
                localStorage.removeItem('token');
                
                // Redirect to force password change
                window.location.hash = '#force-change-password';
                return;
            }
    
            // Normal login process
            const loginSuccess = await auth.login(userData);
            if (!loginSuccess) {
                throw new Error('Failed to initialize user session');
            }
    
            // Show success message
            ui.showError('Login successful!', 'success', 2000);
            form.reset();
    
            // Update UI and redirect
            ui.updateNavigation(true, userData);
            setTimeout(() => {
                window.location.hash = userData.user.role === 'admin' || userData.user.role === 'super' 
                    ? '#admin' 
                    : '#articles';
            }, 300);
    
        } catch (error) {
            console.error('Login error:', error);
            
            const errorMessage = error.message || 'Login failed. Please try again.';
            ui.showError(errorMessage);
            
            if (errorDiv) {
                errorDiv.textContent = errorMessage;
                errorDiv.classList.remove('hidden');
            }
    
            // Only clear password input on error
            if (passwordInput) passwordInput.value = '';
            
            // Only logout on specific errors, not all errors
            if (error.message?.includes('Invalid credentials') || 
                error.message?.includes('Authentication required')) {
                auth.logout();
            }
        } finally {
            ui.hideLoading();
        }
    }

};