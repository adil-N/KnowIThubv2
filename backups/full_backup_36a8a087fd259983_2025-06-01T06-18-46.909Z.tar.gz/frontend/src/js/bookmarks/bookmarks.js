// frontend/src/js/bookmarks/bookmarks.js
import { api } from '../utils/api.js';
import { ui } from '../utils/ui.js';


class Bookmarks {
    constructor() {
        this.initialized = false;
        this.boundHandleClick = this.handleClick.bind(this);
    }

    async initialize() {
        try {
            if (this.initialized) {
                return true;
            }

            ui.showLoading();

            const response = await api.get('/api/bookmarks');
            
            if (!response.success) {
                throw new Error(response.message || 'Failed to load bookmarks');
            }

            const bookmarksSection = document.getElementById('bookmarksSection');
            if (!bookmarksSection) {
                console.error('Bookmarks section not found');
                return false;
            }

            // Keep this class structure that was working with the sidebar
            bookmarksSection.className = 'relative w-full';

            // Use exact container structure from phoneDirectoryList
            bookmarksSection.innerHTML = `
            <div class="container mx-auto py-8" role="main" style="margin-left: ${document.body.classList.contains('sidebar-collapsed') ? '2rem' : '13rem'}">
                <!-- Header -->
                <div class="flex justify-between items-center mb-6">
                    <div class="flex items-center">
                        <span class="material-icons-outlined text-blue-500 text-3xl mr-2">bookmark</span>
                        <h1 class="text-2xl font-bold">My Bookmarks</h1>
                    </div>
                </div>
                
                <!-- No bookmarks message -->
                <div id="noBookmarksMessage" class="hidden text-center py-8 text-gray-500">
                    You have no bookmarked articles.
                </div>

                <!-- Bookmarks grid with proper width constraints -->
                <div id="bookmarksContainer" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 w-full max-w-screen-xl">
                </div>
            </div>
        `;

            const container = document.getElementById('bookmarksContainer');
            const noBookmarksMessage = document.getElementById('noBookmarksMessage');

            if (!container || !noBookmarksMessage) {
                console.error('Required elements not found');
                return false;
            }

            const bookmarkedArticles = response.data || [];
            localStorage.setItem('userBookmarks', JSON.stringify(bookmarkedArticles));

            // Add sidebar state observer
            const mainContainer = bookmarksSection.querySelector('.container[role="main"]');
            if (mainContainer) {
                const observer = new MutationObserver(() => {
                    mainContainer.style.marginLeft = document.body.classList.contains('sidebar-collapsed') ? '2rem' : '13rem';
                });
                
                observer.observe(document.body, {
                    attributes: true,
                    attributeFilter: ['class']
                });
                
                this.observer = observer;
            }

            if (bookmarkedArticles.length === 0) {
                noBookmarksMessage.classList.remove('hidden');
                container.innerHTML = '';
            } else {
                noBookmarksMessage.classList.add('hidden');
                this.renderBookmarks(bookmarkedArticles);
            }

            container.addEventListener('click', this.boundHandleClick);
            this.initialized = true;
            return true;

        } catch (error) {
            console.error('Bookmarks load error:', error);
            ui.showError(error.message || 'Error loading bookmarks');
            return false;
        } finally {
            ui.hideLoading();
        }
    }

    cleanup() {
        this.initialized = false;
        if (this.observer) {
            this.observer.disconnect();
            this.observer = null;
        }
        const bookmarksSection = document.getElementById('bookmarksSection');
        if (bookmarksSection) {
            const container = document.getElementById('bookmarksContainer');
            if (container) {
                container.removeEventListener('click', this.boundHandleClick);
            }
            bookmarksSection.innerHTML = '';
            bookmarksSection.className = 'hidden';
        }
        localStorage.removeItem('userBookmarks');
    }

    // Keep all other methods the same
    escapeHtml(unsafe) {
        if (!unsafe) return '';
        return String(unsafe)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    renderBookmarks(bookmarkedArticles) {
        const container = document.getElementById('bookmarksContainer');
        if (!container) return;
    
        container.innerHTML = bookmarkedArticles.map(article => {
            if (!article || !article._id) return '';
    
            const authorName = article.author ? 
                `${article.author.firstName || ''} ${article.author.lastName || ''}`.trim() || 'Unknown Author' :
                'Unknown Author';
    
            return `
                <div class="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 w-full" 
                     data-article-id="${article._id}">
                    <div class="p-4">
                        <div class="flex flex-col">
                            <div class="flex-grow">
                                <a href="#article/${article._id}" 
                                   class="text-lg font-semibold hover:text-blue-600 mb-2 block truncate">
                                    ${this.escapeHtml(article.title)}
                                </a>
                                <p class="text-sm text-gray-500 mb-2 truncate">
                                    ${article.sections?.map(s => this.escapeHtml(s.name)).join(', ') || 'Uncategorized'}
                                </p>
                                <p class="text-xs text-gray-400">By ${authorName}</p>
                            </div>
                            <div class="flex justify-between items-center mt-4 pt-4 border-t border-gray-100">
                                <span class="text-xs text-gray-400">
                                    ${new Date(article.createdAt).toLocaleDateString()}
                                </span>
                                <button 
                                    type="button"
                                    class="remove-bookmark-btn px-3 py-1 text-sm text-red-500 hover:text-red-700 
                                           hover:bg-red-50 rounded-lg transition-colors"
                                    data-article-id="${article._id}">
                                    Remove
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    handleClick(e) {
        const removeBtn = e.target.closest('.remove-bookmark-btn');
        if (!removeBtn) return;
    
        e.preventDefault();
        e.stopPropagation();
    
        const bookmarkContainer = removeBtn.closest('[data-article-id]');
        const articleId = bookmarkContainer ? bookmarkContainer.getAttribute('data-article-id') : null;
    
        if (!articleId) {
            console.error('No article ID found for removal');
            ui.showError('Failed to identify article for removal');
            return;
        }
    
        this.removeBookmark(articleId);
    }
// Enhance bookmark handling with more logging
async addBookmark(articleId) {
    try {
        console.log('Attempting to bookmark article:', {
            articleId: articleId,
            type: typeof articleId
        });

        // Validate article ID
        if (!articleId) {
            console.error('No article ID provided');
            ui.showError('Please select a valid article to bookmark');
            return;
        }

        ui.showLoading();
        
        const response = await api.post('/api/bookmarks', { articleId });
        
        console.log('Bookmark API Response:', {
            success: response.success,
            message: response.message,
            data: response.data
        });

        if (response.success) {
            ui.showSuccess('Article bookmarked successfully');
            // Optional: Update local storage or UI
        } else {
            throw new Error(response.message || 'Failed to bookmark article');
        }
    } catch (error) {
        console.error('Bookmark error details:', {
            message: error.message,
            stack: error.stack
        });
        ui.showError(error.message || 'Error bookmarking article');
    } finally {
        ui.hideLoading();
    }
}
    async removeBookmark(articleId) {
        try {
            ui.showLoading();
            
            const response = await api.delete(`/api/bookmarks/${articleId}`);
            
            if (response.success) {
                const bookmarkElement = document.querySelector(`[data-article-id="${articleId}"]`);
                if (bookmarkElement) {
                    bookmarkElement.remove();
    
                    const container = document.getElementById('bookmarksContainer');
                    if (container && container.children.length === 0) {
                        const noBookmarksMessage = document.getElementById('noBookmarksMessage');
                        if (noBookmarksMessage) {
                            noBookmarksMessage.classList.remove('hidden');
                        }
                    }
                }
                ui.showSuccess('Bookmark removed');
            } else {
                throw new Error(response.message || 'Failed to remove bookmark');
            }
        } catch (error) {
            console.error('Remove bookmark error:', error);
            ui.showError(error.message || 'Error removing bookmark');
        } finally {
            ui.hideLoading();
        }
    }
}

const bookmarksInstance = new Bookmarks();
export default bookmarksInstance;
export const bookmarks = bookmarksInstance;
window.bookmarks = bookmarksInstance;