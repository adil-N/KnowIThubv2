// config/database.js
const mongoose = require('mongoose');

let isIndexesEnsured = false;

const connectDB = async () => {
    try {
        // Remove deprecated options and simplify connection
        const options = {
            authSource: 'admin',
            // Add timeout and retry options
            serverSelectionTimeoutMS: 5000,
            heartbeatFrequencyMS: 2000,
            retryWrites: true
        };

        // Try to connect with better error handling
        const conn = await mongoose.connect(process.env.MONGODB_URI, options);
        
        if (conn.connection.readyState === 1) {
            console.log('\x1b[32m%s\x1b[0m', '✓ MongoDB connected successfully');
            console.log('Connected to database:', conn.connection.name);
        }

        // Index creation with error handling
        if (!isIndexesEnsured) {
            mongoose.connection.once('connected', async () => {
                try {
                    if (mongoose.connection.models.Article) {
                        await mongoose.connection.models.Article.collection.createIndex(
                            { articleId: 1 },
                            { unique: true, background: true }
                        );
                        console.log('✓ Article indexes created successfully');
                        isIndexesEnsured = true;
                    }
                } catch (indexError) {
                    console.error('Error creating indexes:', indexError.message);
                }
            });
        }

        // Enhanced error monitoring
        mongoose.connection.on('error', err => {
            console.error('\x1b[31m%s\x1b[0m', '✗ MongoDB connection error:', err.message);
            // Attempt to reconnect on error
            setTimeout(connectDB, 5000);
        });

        mongoose.connection.on('disconnected', () => {
            console.log('\x1b[33m%s\x1b[0m', '! MongoDB disconnected, attempting to reconnect...');
            isIndexesEnsured = false;
            setTimeout(connectDB, 5000);
        });

        // Graceful shutdown handling
        process.on('SIGINT', async () => {
            try {
                await mongoose.connection.close();
                console.log('\n\x1b[33m%s\x1b[0m', '! MongoDB connection closed through app termination');
                process.exit(0);
            } catch (err) {
                console.error('\x1b[31m%s\x1b[0m', '✗ Error closing MongoDB connection:', err.message);
                process.exit(1);
            }
        });

        return conn;

    } catch (error) {
        console.error('\x1b[31m%s\x1b[0m', '✗ MongoDB connection error:', error.message);
        // Log detailed error information for debugging
        if (error.name === 'MongooseServerSelectionError') {
            console.error('Details:', {
                message: error.message,
                reason: error.reason,
                code: error.code
            });
            console.log('\nTroubleshooting steps:');
            console.log('1. Verify MongoDB is running: mongod --version');
            console.log('2. Check MongoDB service status');
            console.log('3. Verify connection string in .env file');
            console.log('4. Check firewall settings');
            console.log('5. Verify MongoDB port (default: 27017) is accessible\n');
        }
        
        // Exit with error
        process.exit(1);
    }
};

module.exports = connectDB;