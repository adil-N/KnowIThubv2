// jobs/tagUpdateJob.js
const Article = require('../models/Article');
const TagProcessor = require('../utils/tagProcessor');

class TagUpdateJob {
    constructor() {
        this.isRunning = false;
        this.batchSize = 10;
        this.processor = new TagProcessor();
    }

    async start() {
        if (this.isRunning) {
            console.log('Tag update job is already running');
            return;
        }

        this.isRunning = true;
        console.log('\n=== Starting Tag Update Job ===');

        try {
            await this.processArticles();
            console.log('Tag update job completed successfully');
        } catch (error) {
            console.error('Error in tag update job:', error);
        } finally {
            this.isRunning = false;
        }
    }

    async processArticles() {
        try {
            // Define the query to find articles needing tag processing
            const query = {
                $or: [
                    { autoTags: { $exists: false } },
                    { autoTags: { $size: 0 } },
                    {
                        $and: [
                            { content: { $exists: true } },
                            { content: { $ne: '' } },
                            {
                                $or: [
                                    { tagMeta: { $exists: false } },
                                    { 'tagMeta.lastExtracted': { $exists: false } },
                                    {
                                        'tagMeta.lastExtracted': {
                                            $lt: new Date(Date.now() - 24 * 60 * 60 * 1000)
                                        }
                                    }
                                ]
                            }
                        ]
                    }
                ]
            };

            console.log('\n=== Tag Update Job Debug ===');
            
            // Count total articles
            const totalArticles = await Article.countDocuments();
            console.log(`Total articles in database: ${totalArticles}`);
            
            // Count articles meeting each condition
            const noAutoTags = await Article.countDocuments({ autoTags: { $exists: false } });
            const emptyAutoTags = await Article.countDocuments({ autoTags: { $size: 0 } });
            const noTagMeta = await Article.countDocuments({ tagMeta: { $exists: false } });
            const noLastExtracted = await Article.countDocuments({ 'tagMeta.lastExtracted': { $exists: false } });
            
            console.log('\nArticles by condition:');
            console.log(`- No autoTags field: ${noAutoTags}`);
            console.log(`- Empty autoTags array: ${emptyAutoTags}`);
            console.log(`- No tagMeta: ${noTagMeta}`);
            console.log(`- No lastExtracted date: ${noLastExtracted}`);

            // Find articles that need processing
            const articles = await Article.find(query)
                .limit(this.batchSize)
                .select('title content tags autoTags tagMeta')
                .lean();

            console.log(`Found ${articles.length} articles to process in this batch`);

            // Process each article
            let successCount = 0;
            let errorCount = 0;
            let skippedCount = 0;

            for (const article of articles) {
                try {
                    if (!article.content || article.content.trim().length === 0) {
                        console.log(`Skipping article ${article._id}: No content`);
                        skippedCount++;
                        continue;
                    }

                    const articleDoc = await Article.findById(article._id);
                    if (!articleDoc) {
                        console.log(`Article ${article._id} not found, skipping`);
                        skippedCount++;
                        continue;
                    }

                    await this.processArticle(articleDoc);
                    successCount++;

                } catch (error) {
                    console.error(`Error processing article ${article._id}:`, error);
                    errorCount++;
                }
            }

            console.log('\n=== Processing Summary ===');
            console.log(`Total articles processed: ${articles.length}`);
            console.log(`Successful: ${successCount}`);
            console.log(`Failed: ${errorCount}`);
            console.log(`Skipped: ${skippedCount}`);

            return {
                total: articles.length,
                successful: successCount,
                failed: errorCount,
                skipped: skippedCount
            };

        } catch (error) {
            console.error('Error in processArticles:', error);
            throw error;
        }
    }

    async processArticle(article) {
        try {
            console.log(`\n=== Processing Article: ${article._id} ===`);
            console.log('Article state before processing:', {
                title: article.title,
                currentTags: article.tags || [],
                currentAutoTags: article.autoTags || [],
                hasContent: !!article.content,
                contentLength: article.content?.length || 0,
                tagMeta: article.tagMeta || null
            });

            // Skip if no content
            if (!article.content || article.content.trim().length === 0) {
                console.log('Skipping: No content to process');
                return;
            }

            // Extract tags
            const autoTags = await this.processor.extractTags(
                article.title || '',
                article.content || ''
            );

            console.log('Generated auto tags:', autoTags);

            // Filter out redundant tags
            const filteredTags = this.processor.filterRedundantTags(
                autoTags,
                article.tags || []
            );

            console.log('Filtered tags:', filteredTags);

            // Update article even if no tags (to mark as processed)
            article.autoTags = filteredTags;
            article.tagMeta = {
                lastExtracted: new Date(),
                extractionVersion: (article.tagMeta?.extractionVersion || 0) + 1
            };

            // Force save without triggering pre-save hooks
            await article.save({ timestamps: false });
            
            console.log('Article state after processing:', {
                id: article._id,
                autoTags: article.autoTags,
                tagMeta: article.tagMeta,
                updateTime: new Date()
            });

        } catch (error) {
            console.error(`Error processing article ${article._id}:`, error);
            throw error;
        }
    }

    async processNewArticle(articleId) {
        try {
            console.log(`\n=== Processing New Article: ${articleId} ===`);
            
            const article = await Article.findById(articleId);
            if (!article) {
                throw new Error('Article not found');
            }

            await this.processArticle(article);
            return true;
        } catch (error) {
            console.error('Error processing new article:', error);
            return false;
        }
    }
}

// Export a single instance
module.exports = new TagUpdateJob();