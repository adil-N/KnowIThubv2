// middleware/superAdminAuth.js
const ApiResponse = require('../utils/apiResponse');

const superAdminAuth = (req, res, next) => {
    if (req.user && req.user.role === 'super') {
        next();
    } else {
        return ApiResponse.forbidden(res, 'Super admin access required');
    }
};

module.exports = superAdminAuth;
