// frontend/src/js/admin/sectionManagement.js
import { api } from '../utils/api.js';
import { ui } from '../utils/ui.js';

export const sectionManagement = {
    async show(container) {
        try {
            const response = await api.get('/api/sections');
            if (!response.success) {
                throw new Error(response.message || 'Failed to load sections');
            }

            const sections = response.data || [];
            
            container.innerHTML = `
                <div class="w-full">
                    <div class="flex justify-between items-center mb-8">
                        <h2 class="text-2xl font-bold">Section Management</h2>
                        <button id="createSectionBtn" 
                            class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                            Create Section
                        </button>
                    </div>
                    
                    <div class="overflow-x-auto bg-white rounded-lg shadow mb-20">
                        <table class="min-w-full bg-white">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="border px-4 py-2 text-left">Name</th>
                                    <th class="border px-4 py-2 text-left">Description</th>
                                    <th class="border px-4 py-2 text-left">Parent Section</th>
                                    <th class="border px-4 py-2 text-left w-32">Order</th>
                                    <th class="border px-4 py-2 text-left">Status</th>
                                    <th class="border px-4 py-2 text-left">Actions</th>
                                </tr>
                            </thead>
                            <tbody id="sectionsTableBody">
                                ${sections.map(section => this.renderSectionRow(section)).join('')}
                            </tbody>
                        </table>
                        <!-- Extra space to prevent tooltip conflicts with browser status bar -->
                        <div class="h-20"></div>
                    </div>
                </div>
                
                <!-- Global tooltip element -->
                <div id="sectionTooltip" class="section-tooltip">
                    <div class="tooltip-content"></div>
                </div>
            `;

            this.attachEventListeners();
            this.setupDragAndDrop();
            this.initializeTooltips();
        } catch (error) {
            console.error('Error loading sections:', error);
            ui.showError('Failed to load sections');
        }
    },

    renderSectionRow(section) {
        return `
            <tr data-section-id="${section._id}" class="section-row cursor-move">
                <td class="border px-4 py-2">
                    <div class="flex items-center section-name-container" 
                         data-tooltip="${this.escapeHtml(section.description || 'No description available')}">
                        <span class="material-icons-outlined text-gray-400 mr-2 drag-handle cursor-move">drag_indicator</span>
                        <span class="section-name">${section.name}</span>
                    </div>
                </td>
                <td class="border px-4 py-2">${section.description || '-'}</td>
                <td class="border px-4 py-2">${section.parentSection?.name || '-'}</td>
                <td class="border px-4 py-2">
                    <div class="flex items-center space-x-2">
                        <input type="number" 
                            class="order-input w-16 px-2 py-1 border rounded"
                            value="${section.order}"
                            min="1"
                            data-original-value="${section.order}"
                        >
                    </div>
                </td>
                <td class="border px-4 py-2">
                    <button onclick="window.toggleSectionStatus('${section._id}', ${section.isActive})" 
                        class="w-full px-2 py-1 rounded text-center ${section.isActive ? 
                            'bg-green-100 text-green-800 hover:bg-green-200' : 
                            'bg-red-100 text-red-800 hover:bg-red-200'}">
                        ${section.isActive ? 'Active' : 'Inactive'}
                    </button>
                </td>
                <td class="border px-4 py-2">
                    <button onclick="window.editSection('${section._id}')" 
                        class="bg-blue-500 text-white px-2 py-1 rounded mr-2 hover:bg-blue-600">
                        Edit
                    </button>
                    <button onclick="window.deleteSection('${section._id}')"
                        class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600">
                        Delete
                    </button>
                </td>
            </tr>
        `;
    },

    // Helper function to escape HTML
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },

    // Initialize modern tooltips
    initializeTooltips() {
        const tooltip = document.getElementById('sectionTooltip');
        const tooltipContent = tooltip.querySelector('.tooltip-content');
        let currentTimeout = null;
        
        document.querySelectorAll('.section-name-container').forEach(container => {
            const sectionName = container.querySelector('.section-name');
            
            container.addEventListener('mouseenter', (e) => {
                const tooltipText = container.dataset.tooltip;
                if (!tooltipText || tooltipText === 'No description available') return;
                
                // Clear any existing timeout
                if (currentTimeout) {
                    clearTimeout(currentTimeout);
                    currentTimeout = null;
                }
                
                tooltipContent.textContent = tooltipText;
                
                // Small delay to prevent flickering
                currentTimeout = setTimeout(() => {
                    this.positionTooltip(e, tooltip, container);
                    tooltip.classList.add('show');
                }, 100);
            });

            container.addEventListener('mouseleave', () => {
                // Clear timeout if mouse leaves before delay
                if (currentTimeout) {
                    clearTimeout(currentTimeout);
                    currentTimeout = null;
                }
                
                tooltip.classList.remove('show');
                
                // Reset positioning classes after fade out
                setTimeout(() => {
                    tooltip.classList.remove('tooltip-left', 'tooltip-right', 'tooltip-top', 'tooltip-bottom');
                }, 200);
            });
        });
        
        // Handle window resize to reposition visible tooltips
        window.addEventListener('resize', () => {
            if (tooltip.classList.contains('show')) {
                tooltip.classList.remove('show');
            }
        });
    },

    // Position tooltip relative to the section name
    positionTooltip(event, tooltip, container) {
        // Force a layout update to get accurate measurements
        tooltip.style.visibility = 'hidden';
        tooltip.style.display = 'block';
        
        const containerRect = container.getBoundingClientRect();
        const tooltipRect = tooltip.getBoundingClientRect();
        const viewportWidth = window.innerWidth;
        const viewportHeight = window.innerHeight;
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
        
        // Reset classes
        tooltip.classList.remove('tooltip-left', 'tooltip-right', 'tooltip-top', 'tooltip-bottom');
        
        // Calculate base positions
        const containerCenterY = containerRect.top + (containerRect.height / 2);
        const containerCenterX = containerRect.left + (containerRect.width / 2);
        
        // Reserve space for browser status bar (typically 20-25px from bottom)
        const statusBarHeight = 60; // Extra buffer for browser status bar
        const availableHeight = viewportHeight - statusBarHeight;
        
        let left, top, placement = 'right';
        
        // Try right placement first (preferred for tables)
        left = containerRect.right + 15;
        top = containerCenterY - (tooltipRect.height / 2);
        
        // Check if tooltip fits on the right
        if (left + tooltipRect.width > viewportWidth - 20) {
            // Try left placement
            left = containerRect.left - tooltipRect.width - 15;
            placement = 'left';
            
            // If still doesn't fit horizontally, try vertical placements
            if (left < 20) {
                // Try top placement first (to avoid status bar)
                left = containerCenterX - (tooltipRect.width / 2);
                top = containerRect.top - tooltipRect.height - 15;
                placement = 'top';
                
                // If top doesn't fit, use bottom but with extra margin
                if (top < 20) {
                    top = containerRect.bottom + 15;
                    placement = 'bottom';
                    
                    // If bottom placement would conflict with status bar, force top
                    if (top + tooltipRect.height > availableHeight) {
                        top = containerRect.top - tooltipRect.height - 15;
                        placement = 'top';
                        
                        // If top still doesn't fit, place it at the top of viewport
                        if (top < 20) {
                            top = 20;
                        }
                    }
                }
                
                // Ensure horizontal centering stays within viewport
                if (left < 20) {
                    left = 20;
                } else if (left + tooltipRect.width > viewportWidth - 20) {
                    left = viewportWidth - tooltipRect.width - 20;
                }
            }
        }
        
        // Ensure vertical position stays within viewport for side placements
        if (placement === 'left' || placement === 'right') {
            if (top < 20) {
                top = 20;
            } else if (top + tooltipRect.height > availableHeight) {
                top = availableHeight - tooltipRect.height - 20;
            }
        }
        
        // Add placement class for arrow positioning
        tooltip.classList.add(`tooltip-${placement}`);
        
        // Apply position with scroll offset
        tooltip.style.left = `${left + scrollLeft}px`;
        tooltip.style.top = `${top + scrollTop}px`;
        tooltip.style.visibility = 'visible';
        tooltip.style.display = 'block';
    },

    attachEventListeners() {
        document.getElementById('createSectionBtn')?.addEventListener('click', () => {
            this.showSectionModal();
        });

        // Add event listeners for order input changes
        document.querySelectorAll('.order-input').forEach(input => {
            input.addEventListener('change', async (e) => {
                const newOrder = parseInt(e.target.value);
                const originalOrder = parseInt(e.target.dataset.originalValue);
                const row = e.target.closest('.section-row');
                const sectionId = row.dataset.sectionId;

                if (newOrder !== originalOrder) {
                    try {
                        ui.showLoading();
                        const response = await api.put(`/api/sections/${sectionId}/reorder`, {
                            newOrder: newOrder
                        });

                        if (!response.success) {
                            throw new Error(response.message);
                        }

                        // Refresh the section list to show new order
                        await this.show(document.getElementById('adminContent'));
                        ui.showError('Section order updated successfully', 'success');
                    } catch (error) {
                        console.error('Error updating section order:', error);
                        ui.showError(error.message);
                        // Reset to original value on error
                        e.target.value = originalOrder;
                    } finally {
                        ui.hideLoading();
                    }
                }
            });
        });
    },

    setupDragAndDrop() {
        const tbody = document.getElementById('sectionsTableBody');
        if (!tbody) return;
    
        new Sortable(tbody, {
            handle: '.drag-handle',
            animation: 150,
            onEnd: async (evt) => {
                const sectionId = evt.item.dataset.sectionId;
                const newOrder = evt.newIndex + 1; // Add 1 because array indices are 0-based
    
                try {
                    ui.showLoading();
                    const response = await api.put(`/api/sections/${sectionId}/reorder`, {
                        newOrder: newOrder
                    });
    
                    if (!response.success) {
                        throw new Error(response.message);
                    }
    
                    // Refresh the section list to show new order
                    await this.show(document.getElementById('adminContent'));
                    ui.showError('Section order updated successfully', 'success');
                } catch (error) {
                    console.error('Error updating section order:', error);
                    ui.showError(error.message);
                    // Refresh the list to ensure correct order display
                    await this.show(document.getElementById('adminContent'));
                } finally {
                    ui.hideLoading();
                }
            }
        });
    },

    async showSectionModal(sectionData = null) {
        const isEditing = !!sectionData;
        
        // Fetch parent sections for dropdown
        const response = await api.get('/api/sections');
        const parentOptions = response.success ? response.data
            .filter(s => !sectionData || s._id !== sectionData._id)
            .map(s => `<option value="${s._id}" ${sectionData?.parentSection?._id === s._id ? 'selected' : ''}>${s.name}</option>`)
            .join('') : '';

        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold">${isEditing ? 'Edit' : 'Create'} Section</h3>
                    <button class="text-gray-500 hover:text-gray-700" onclick="this.closest('.fixed').remove()">✕</button>
                </div>
                <form id="sectionForm" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Name</label>
                        <input type="text" name="name" required
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                            value="${sectionData?.name || ''}"
                        >
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Description</label>
                        <textarea name="description" rows="3"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        >${sectionData?.description || ''}</textarea>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Parent Section</label>
                        <select name="parentSection"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                        >
                            <option value="">None</option>
                            ${parentOptions}
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Order</label>
                        <input type="number" name="order"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                            value="${sectionData?.order || 0}"
                        >
                    </div>
                    ${isEditing ? `
                        <div>
                            <label class="flex items-center">
                                <input type="checkbox" name="isActive"
                                    class="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                                    ${sectionData.isActive ? 'checked' : ''}
                                >
                                <span class="ml-2 text-sm text-gray-600">Active</span>
                            </label>
                        </div>
                    ` : ''}
                    <div class="flex justify-end space-x-3 mt-6">
                        <button type="button" onclick="this.closest('.fixed').remove()"
                            class="px-4 py-2 border rounded-md text-gray-700 hover:bg-gray-50">
                            Cancel
                        </button>
                        <button type="submit"
                            class="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">
                            ${isEditing ? 'Update' : 'Create'}
                        </button>
                    </div>
                </form>
            </div>
        `;

        document.body.appendChild(modal);

        modal.querySelector('#sectionForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = {
                name: formData.get('name'),
                description: formData.get('description'),
                parentSection: formData.get('parentSection') || null,
                order: parseInt(formData.get('order')) || 0
            };

            if (isEditing) {
                data.isActive = formData.get('isActive') === 'on';
            }

            try {
                ui.showLoading();
                const response = await api[isEditing ? 'put' : 'post'](
                    `/api/sections${isEditing ? `/${sectionData._id}` : ''}`,
                    data
                );

                if (!response.success) {
                    throw new Error(response.message || `Failed to ${isEditing ? 'update' : 'create'} section`);
                }

                modal.remove();
                await this.show(document.getElementById('adminContent'));
                ui.showError(`Section ${isEditing ? 'updated' : 'created'} successfully`, 'success');
            } catch (error) {
                console.error('Section operation error:', error);
                ui.showError(error.message);
            } finally {
                ui.hideLoading();
            }
        });
    }
};

// Add global handlers
window.editSection = async (sectionId) => {
    try {
        ui.showLoading();
        const response = await api.get(`/api/sections/${sectionId}`);
        if (!response.success) {
            throw new Error(response.message || 'Failed to fetch section details');
        }
        await sectionManagement.showSectionModal(response.data);
    } catch (error) {
        console.error('Error editing section:', error);
        ui.showError(error.message);
    } finally {
        ui.hideLoading();
    }
};

window.deleteSection = async (sectionId) => {
    if (!confirm('Are you sure you want to delete this section? This will not delete any articles in the section.')) {
        return;
    }

    try {
        ui.showLoading();
        const response = await api.delete(`/api/sections/${sectionId}`);
        if (!response.success) {
            throw new Error(response.message || 'Failed to delete section');
        }
        await sectionManagement.show(document.getElementById('adminContent'));
        ui.showError('Section deleted successfully', 'success');
    } catch (error) {
        console.error('Error deleting section:', error);
        ui.showError(error.message);
    } finally {
        ui.hideLoading();
    }
};

window.toggleSectionStatus = async (sectionId, currentStatus) => {
    try {
        ui.showLoading();
        const response = await api.put(`/api/sections/${sectionId}`, {
            isActive: !currentStatus
        });

        if (!response.success) {
            throw new Error(response.message || 'Failed to update section status');
        }

        await sectionManagement.show(document.getElementById('adminContent'));
        ui.showError(`Section ${!currentStatus ? 'activated' : 'deactivated'} successfully`, 'success');
    } catch (error) {
        console.error('Error updating section status:', error);
        ui.showError(error.message);
    } finally {
        ui.hideLoading();
    }
};