// controllers/sectionController.js
const Section = require('../models/Section');
const Article = require('../models/Article');


async function normalizeOrders() {
    const sections = await Section.find().sort('order');
    const updates = sections.map((section, index) => 
        Section.updateOne(
            { _id: section._id },
            { $set: { order: index + 1 } }
        )
    );
    await Promise.all(updates);
}

exports.createSection = async (req, res) => {
    try {
        const { name, description, parentSection, icon } = req.body;
        
        // Find the highest order number
        const maxOrderSection = await Section.findOne().sort('-order');
        const nextOrder = maxOrderSection ? maxOrderSection.order + 1 : 1;
        
        const section = new Section({
            name,
            description,
            parentSection: parentSection || null,
            icon: icon || 'folder',
            order: nextOrder,
            createdBy: req.user._id
        });

        await section.save();
        await normalizeOrders(); // Normalize orders after creation

        res.status(201).json({
            success: true,
            data: section
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
};
// reorder sections
exports.reorderSection = async (req, res) => {
    try {
        const { id } = req.params;
        const { newOrder } = req.body;

        const section = await Section.findById(id);
        if (!section) {
            return res.status(404).json({
                success: false,
                message: 'Section not found'
            });
        }

        // Get total number of sections
        const totalSections = await Section.countDocuments();
        
        // Validate new order
        if (newOrder < 1 || newOrder > totalSections) {
            return res.status(400).json({
                success: false,
                message: 'Invalid order number'
            });
        }

        const oldOrder = section.order;

        // Update orders for all affected sections
        if (newOrder < oldOrder) {
            // Moving up: increment orders of sections in between
            await Section.updateMany(
                { order: { $gte: newOrder, $lt: oldOrder } },
                { $inc: { order: 1 } }
            );
        } else if (newOrder > oldOrder) {
            // Moving down: decrement orders of sections in between
            await Section.updateMany(
                { order: { $gt: oldOrder, $lte: newOrder } },
                { $inc: { order: -1 } }
            );
        }

        // Update the section's order
        section.order = newOrder;
        await section.save();

        // Normalize all orders to ensure sequential numbers
        await normalizeOrders();

        res.json({
            success: true,
            message: 'Section reordered successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};
exports.getAllSections = async (req, res) => {
    try {
        // First normalize all orders
        await normalizeOrders();
        
        // Then fetch all sections
        const sections = await Section.find({ isActive: true })
            .populate('parentSection', 'name')
            .sort('order');
            
        res.json({
            success: true,
            data: sections
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};
exports.getSectionTree = async (req, res) => {
    try {
        const tree = await Section.getTree();
        res.json({
            success: true,
            data: tree
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.updateSection = async (req, res) => {
    try {
        const { name, description, parentSection, icon, order, isActive } = req.body;
        const section = await Section.findById(req.params.id);

        if (!section) {
            return res.status(404).json({
                success: false,
                message: 'Section not found'
            });
        }

        // Update fields
        if (name) section.name = name;
        if (description !== undefined) section.description = description;
        if (parentSection !== undefined) section.parentSection = parentSection || null;
        if (icon) section.icon = icon;
        if (order !== undefined) section.order = order;
        if (isActive !== undefined) section.isActive = isActive;

        await section.save();
        
        res.json({
            success: true,
            data: section
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            message: error.message
        });
    }
};

exports.deleteSection = async (req, res) => {
    try {
        const section = await Section.findById(req.params.id);
        
        if (!section) {
            return res.status(404).json({
                success: false,
                message: 'Section not found'
            });
        }

        const canDelete = await section.canDelete();
        if (!canDelete) {
            return res.status(400).json({
                success: false,
                message: 'Cannot delete section with articles or child sections'
            });
        }

        await Section.deleteOne({ _id: section._id });
        
        res.json({
            success: true,
            message: 'Section deleted successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

exports.getSectionArticles = async (req, res) => {
    try {
        const { page = 1, limit = 15 } = req.query;
        const articles = await Article.findBySection(req.params.id, page, limit);
        
        res.json({
            success: true,
            data: articles
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


exports.getSection = async (req, res) => {
    try {
        const section = await Section.findById(req.params.id)
            .populate('parentSection', 'name slug');

        if (!section) {
            return res.status(404).json({
                success: false,
                message: 'Section not found'
            });
        }
        
        res.json({
            success: true,
            data: section
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
}; 

// Add as a separate export
exports.getActiveSections = async (req, res) => {
    try {
        const sections = await Section.find({ isActive: true })
            .sort({ order: 1, name: 1 })
            .select('name order');
            
        res.json({
            success: true,
            data: sections
        });
    } catch (error) {
        console.error('Error fetching active sections:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching active sections',
            error: error.message
        });
    }
};