// controllers/adminController.js - Complete Fixed Version
const User = require('../models/User');
const Article = require('../models/Article');
const Comment = require('../models/Comment');
const bcrypt = require('bcryptjs');
const inviteCodeManager = require('../utils/inviteCodeManager');
const ApiResponse = require('../utils/apiResponse');
const AdminLog = require('../models/AdminLog');

const adminController = {
    getStats: async (req, res) => {
        try {
            // Basic stats
            const [totalUsers, activeUsers, inactiveUsers, adminUsers] = await Promise.all([
                User.countDocuments(),
                User.countDocuments({ status: 'active' }),
                User.countDocuments({ status: 'inactive' }),
                User.countDocuments({ role: 'admin' })
            ]);

            const [totalArticles, hiddenArticles, totalComments] = await Promise.all([
                Article.countDocuments(),
                Article.countDocuments({ hidden: true }),
                Comment.countDocuments()
            ]);

            // Most Active Users with weighted scoring
            const mostActiveUsers = await User.aggregate([
                {
                    $lookup: {
                        from: 'articles',
                        localField: '_id',
                        foreignField: 'author',
                        as: 'articles'
                    }
                },
                {
                    $lookup: {
                        from: 'comments',
                        localField: '_id',
                        foreignField: 'author',
                        as: 'comments'
                    }
                },
                {
                    $addFields: {
                        articleCount: { $size: '$articles' },
                        commentCount: { $size: '$comments' },
                        lastActive: {
                            $max: [
                                '$lastLogin',
                                { $max: '$articles.createdAt' },
                                { $max: '$comments.createdAt' }
                            ]
                        },
                        lastWeekLogin: {
                            $cond: {
                                if: {
                                    $gte: ['$lastLogin', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)]
                                },
                                then: 5,
                                else: 0
                            }
                        }
                    }
                },
                {
                    $addFields: {
                        activityScore: {
                            $add: [
                                { $multiply: ['$articleCount', 10] },
                                { $multiply: ['$commentCount', 2] },
                                '$lastWeekLogin'
                            ]
                        }
                    }
                },
                {
                    $project: {
                        _id: 1, 
                        email: 1,
                        firstName: 1,
                        lastName: 1,
                        articleCount: 1,
                        commentCount: 1,
                        lastActive: 1,
                        activityScore: 1
                    }
                },
                { $sort: { activityScore: -1 } },
                { $limit: 10 }
            ]);

            // Top Articles - Fixed implementation
            const topArticles = await Article.aggregate([
                {
                    $match: {
                        $or: [
                            { hidden: false },
                            { hidden: { $exists: false } }
                        ]
                    }
                },
                {
                    $lookup: {
                        from: 'comments',
                        localField: '_id',
                        foreignField: 'article',
                        as: 'comments'
                    }
                },
                {
                    $lookup: {
                        from: 'users',
                        localField: 'author',
                        foreignField: '_id',
                        as: 'authorDetails'
                    }
                },
                {
                    $addFields: {
                        commentCount: { $size: '$comments' },
                        author: { $arrayElemAt: ['$authorDetails', 0] },
                        views: { $ifNull: ['$views', { $multiply: [{ $size: '$comments' }, 3] }] }
                    }
                },
                {
                    $addFields: {
                        engagementScore: {
                            $add: [
                                { $multiply: ['$commentCount', 5] },
                                { $ifNull: ['$views', 0] }
                            ]
                        }
                    }
                },
                {
                    $project: {
                        title: 1,
                        'author.email': 1,
                        'author.firstName': 1,
                        'author.lastName': 1,
                        commentCount: 1,
                        views: 1,
                        createdAt: 1,
                        engagementScore: 1
                    }
                },
                { $sort: { engagementScore: -1 } },
                { $limit: 10 }
            ]);

            console.log('topArticles result:', topArticles?.length || 0, 'articles found');

            // Latest Activity with comprehensive tracking
            const latestActivity = await AdminLog.aggregate([
                {
                    $lookup: {
                        from: 'users',
                        localField: 'adminId',
                        foreignField: '_id',
                        as: 'user'
                    }
                },
                { 
                    $unwind: {
                        path: '$user',
                        preserveNullAndEmptyArrays: true
                    }
                },
                {
                    $project: {
                        'user.email': 1,
                        'user.firstName': 1,
                        'user.lastName': 1,
                        action: 1,
                        details: 1,
                        timestamp: 1
                    }
                },
                { $sort: { timestamp: -1 } },
                { $limit: 20 }
            ]);

            // Add recent user activities (not just admin logs)
            const recentUserActivities = await Promise.all([
                // Recent user registrations
                User.find({
                    createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
                })
                .select('email firstName lastName createdAt')
                .sort({ createdAt: -1 })
                .limit(5)
                .lean(),

                // Recent article creations
                Article.find({
                    createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
                })
                .populate('author', 'email firstName lastName')
                .select('title author createdAt')
                .sort({ createdAt: -1 })
                .limit(5)
                .lean(),

                // Recent comments
                Comment.find({
                    createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
                })
                .populate('author', 'email firstName lastName')
                .populate('article', 'title')
                .select('author article createdAt')
                .sort({ createdAt: -1 })
                .limit(5)
                .lean(),

                // Recent logins (users who logged in today)
                User.find({
                    lastLogin: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
                })
                .select('email firstName lastName lastLogin')
                .sort({ lastLogin: -1 })
                .limit(10)
                .lean()
            ]);

            // Combine and format all activities
            const combinedActivities = [];

            // Add user registrations
            recentUserActivities[0].forEach(user => {
                combinedActivities.push({
                    user: { email: user.email, firstName: user.firstName, lastName: user.lastName },
                    action: 'USER_CREATED',
                    details: 'New user registration',
                    timestamp: user.createdAt
                });
            });

            // Add article creations
            recentUserActivities[1].forEach(article => {
                combinedActivities.push({
                    user: { 
                        email: article.author?.email, 
                        firstName: article.author?.firstName, 
                        lastName: article.author?.lastName 
                    },
                    action: 'ARTICLE_CREATED',
                    details: `Created article: ${article.title}`,
                    timestamp: article.createdAt
                });
            });

            // Add comments
            recentUserActivities[2].forEach(comment => {
                combinedActivities.push({
                    user: { 
                        email: comment.author?.email, 
                        firstName: comment.author?.firstName, 
                        lastName: comment.author?.lastName 
                    },
                    action: 'COMMENT_ADDED',
                    details: `Commented on: ${comment.article?.title}`,
                    timestamp: comment.createdAt
                });
            });

            // Add recent logins
            recentUserActivities[3].forEach(user => {
                combinedActivities.push({
                    user: { email: user.email, firstName: user.firstName, lastName: user.lastName },
                    action: 'USER_LOGIN',
                    details: 'User logged in',
                    timestamp: user.lastLogin
                });
            });

            // Add admin activities
            latestActivity.forEach(activity => {
                combinedActivities.push(activity);
            });

            // Sort all activities by timestamp (most recent first)
            combinedActivities.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

            // User Contributions
            const userContributions = await User.aggregate([
                {
                    $lookup: {
                        from: 'articles',
                        localField: '_id',
                        foreignField: 'author',
                        as: 'articles'
                    }
                },
                {
                    $lookup: {
                        from: 'comments',
                        localField: '_id',
                        foreignField: 'author',
                        as: 'comments'
                    }
                },
                {
                    $addFields: {
                        articlesCount: { $size: '$articles' },
                        commentsCount: { $size: '$comments' },
                        totalContributions: {
                            $add: [
                                { $size: '$articles' },
                                { $size: '$comments' }
                            ]
                        }
                    }
                },
                {
                    $project: {
                        email: 1,
                        role: 1,
                        lastLogin: 1,
                        articlesCount: 1,
                        commentsCount: 1,
                        totalContributions: 1
                    }
                },
                { $sort: { totalContributions: -1 } }
            ]);

            // Activity Timeline (last 7 days)
            const last7Days = [...Array(7)].map((_, i) => {
                const date = new Date();
                date.setDate(date.getDate() - (6 - i));
                return date.toISOString().split('T')[0];
            });

            const activityPromises = last7Days.map(async date => {
                const startDate = new Date(date);
                const endDate = new Date(date);
                endDate.setDate(endDate.getDate() + 1);

                const [logins, articles, comments] = await Promise.all([
                    User.countDocuments({
                        lastLogin: { $gte: startDate, $lt: endDate }
                    }),
                    Article.countDocuments({
                        createdAt: { $gte: startDate, $lt: endDate }
                    }),
                    Comment.countDocuments({
                        createdAt: { $gte: startDate, $lt: endDate }
                    })
                ]);

                return {
                    date,
                    logins,
                    articles,
                    comments,
                    total: logins + articles + comments
                };
            });

            const activityData = await Promise.all(activityPromises);

            // Today's activity stats
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            const [todayLogins, newArticles, newComments, activeUsersToday] = await Promise.all([
                User.countDocuments({ lastLogin: { $gte: today } }),
                Article.countDocuments({ createdAt: { $gte: today } }),
                Comment.countDocuments({ createdAt: { $gte: today } }),
                User.countDocuments({ lastLogin: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) } })
            ]);

            // Compile all stats
            const stats = {
                users: {
                    total: totalUsers,
                    active: activeUsers,
                    inactive: inactiveUsers,
                    admins: adminUsers
                },
                content: {
                    articles: totalArticles,
                    comments: totalComments,
                    hiddenArticles
                },
                activity: {
                    todayLogins,
                    newArticles,
                    newComments,
                    activeUsers: activeUsersToday
                },
                mostActiveUsers,
                topArticles, // Fixed: This will now be included
                latestActivity: combinedActivities.slice(0, 30),
                userContributions,
                userActivity: {
                    labels: activityData.map(d => d.date),
                    values: activityData.map(d => d.total)
                },
                contentGrowth: {
                    labels: activityData.map(d => d.date),
                    articles: activityData.map(d => d.articles),
                    comments: activityData.map(d => d.comments)
                },
                system: {
                    lastBackup: process.env.LAST_BACKUP_DATE || null,
                    storageUsed: await calculateStorageUsed()
                }
            };

            console.log('Sending stats response:', {
                topArticlesCount: stats.topArticles.length,
                activitiesCount: stats.latestActivity.length,
                timestamp: new Date().toISOString()
            });

            res.json({
                success: true,
                data: stats,
                timestamp: new Date().toISOString()
            });

        } catch (error) {
            console.error('Error fetching admin statistics:', error);
            res.status(500).json({
                success: false,
                message: 'Error fetching statistics',
                error: error.message
            });
        }
    },
    
    // Get all users
    getUsers: async (req, res) => {
        try {
            const users = await User.find()
                .select('email firstName lastName role status createdAt lastLogin')
                .sort({ createdAt: -1 })
                .lean();

            return res.json({
                success: true,
                data: users,
                count: users.length,
                timestamp: new Date().toISOString()
            });
        } catch (error) {
            console.error('Error fetching users:', error);
            return res.status(500).json({
                success: false,
                message: 'Error fetching users',
                error: error.message
            });
        }
    },
    
    // Get admin users
    getAdmins: async (req, res) => {
        try {
            const admins = await User.find({ role: 'admin' })
                .select('-password')
                .sort({ createdAt: -1 });
            res.json({ success: true, data: admins });
        } catch (error) {
            console.error('Error fetching admins:', error);
            res.status(500).json({ success: false, message: 'Error fetching admins' });
        }
    },

    // Reset user password
    resetUserPassword: async (req, res) => {
        try {
            const user = await User.findById(req.params.userId);
            if (!user) {
                return res.status(404).json({ success: false, message: 'User not found' });
            }

            // Generate a simpler but still secure temporary password
            const tempPassword = `TempPass${Math.floor(10000 + Math.random() * 90000)}`; // Format: TempPass12345

            // Hash the password
            const salt = await bcrypt.genSalt(10);
            const hashedPassword = await bcrypt.hash(tempPassword, salt);

            // Update user with new password and force reset
            await User.findByIdAndUpdate(user._id, {
                password: hashedPassword,
                passwordResetRequired: true,
                loginAttempts: 0,
                lockUntil: null,
                $set: {
                    passwordResetAt: new Date()
                }
            });

            console.log('Password reset completed for user:', user.email);
            console.log('New temp password (hashed):', hashedPassword);

            res.json({
                success: true,
                message: 'Password reset successful',
                data: { 
                    temporaryPassword: tempPassword,
                    email: user.email,
                    requiresReset: true
                }
            });
        } catch (error) {
            console.error('Error resetting password:', error);
            res.status(500).json({ 
                success: false, 
                message: 'Error resetting password',
                error: error.message 
            });
        }
    },

    // Delete user
    deleteUser: async (req, res) => {
        try {
            const user = await User.findById(req.params.userId);
            if (!user) {
                return res.status(404).json({ success: false, message: 'User not found' });
            }

            if (user.role === 'super') {
                return res.status(403).json({ success: false, message: 'Cannot delete super admin' });
            }

            await user.deleteOne();
            res.json({ success: true, message: 'User deleted successfully' });
        } catch (error) {
            console.error('Error deleting user:', error);
            res.status(500).json({ success: false, message: 'Error deleting user' });
        }
    },

    // Update user status
    updateUserStatus: async (req, res) => {
        try {
            const { status } = req.body;
            if (!['active', 'inactive', 'suspended'].includes(status)) {
                return res.status(400).json({ success: false, message: 'Invalid status' });
            }

            const user = await User.findById(req.params.userId);
            if (!user) {
                return res.status(404).json({ success: false, message: 'User not found' });
            }

            if (user.role === 'super') {
                return res.status(403).json({ success: false, message: 'Cannot modify super admin status' });
            }

            user.status = status;
            await user.save();

            res.json({ success: true, message: 'User status updated successfully' });
        } catch (error) {
            console.error('Error updating user status:', error);
            res.status(500).json({ success: false, message: 'Error updating user status' });
        }
    },

    // Update user role (super admin only)
    updateUserRole: async (req, res) => {
        try {
            const { role } = req.body;
            if (!['user', 'admin'].includes(role)) {
                return res.status(400).json({ success: false, message: 'Invalid role' });
            }

            const user = await User.findById(req.params.userId);
            if (!user) {
                return res.status(404).json({ success: false, message: 'User not found' });
            }

            if (user.role === 'super') {
                return res.status(403).json({ success: false, message: 'Cannot modify super admin role' });
            }

            user.role = role;
            await user.save();

            res.json({ success: true, message: 'User role updated successfully' });
        } catch (error) {
            console.error('Error updating user role:', error);
            res.status(500).json({ success: false, message: 'Error updating user role' });
        }
    },
    
    // Update admin name
    updateAdminName: async (req, res) => {
        try {
            const { firstName, lastName } = req.body;
            const admin = await User.findById(req.params.adminId);
            
            if (!admin || admin.role !== 'admin') {
                return res.status(404).json({ success: false, message: 'Admin not found' });
            }

            admin.firstName = firstName;
            admin.lastName = lastName;
            await admin.save();

            res.json({ success: true, message: 'Admin name updated successfully' });
        } catch (error) {
            console.error('Error updating admin name:', error);
            res.status(500).json({ success: false, message: 'Error updating admin name' });
        }
    },


// Get pending users
getPendingUsers: async (req, res) => {
    try {
        const pendingUsers = await User.find({ status: 'pending' })
            .select('email firstName lastName createdAt')
            .sort({ createdAt: -1 })
            .lean();

        return res.json({
            success: true,
            data: pendingUsers,
            count: pendingUsers.length,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('Error fetching pending users:', error);
        return res.status(500).json({
            success: false,
            message: 'Error fetching pending users',
            error: error.message
        });
    }
},

// Approve user
approveUser: async (req, res) => {
    try {
        const user = await User.findById(req.params.userId);
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        if (user.status !== 'pending') {
            return res.status(400).json({ success: false, message: 'User is not pending approval' });
        }

        user.status = 'active';
        await user.save();

        console.log('User approved by admin:', {
            userId: user._id,
            email: user.email,
            approvedBy: req.user._id
        });

        res.json({ 
            success: true, 
            message: 'User approved successfully',
            data: {
                userId: user._id,
                email: user.email,
                status: user.status
            }
        });
    } catch (error) {
        console.error('Error approving user:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error approving user',
            error: error.message 
        });
    }
},

// Reject user
rejectUser: async (req, res) => {
    try {
        const user = await User.findById(req.params.userId);
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found' });
        }

        if (user.status !== 'pending') {
            return res.status(400).json({ success: false, message: 'User is not pending approval' });
        }

        console.log('User rejected by admin:', {
            userId: user._id,
            email: user.email,
            rejectedBy: req.user._id
        });

        // Delete the user record completely
        await user.deleteOne();

        res.json({ 
            success: true, 
            message: 'User rejected and removed successfully'
        });
    } catch (error) {
        console.error('Error rejecting user:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error rejecting user',
            error: error.message 
        });
    }
},

// Update the existing getUsers method to include status filtering
getUsers: async (req, res) => {
    try {
        const { status } = req.query;
        
        let filter = {};
        if (status && ['pending', 'active', 'inactive', 'suspended'].includes(status)) {
            filter.status = status;
        }

        const users = await User.find(filter)
            .select('email firstName lastName role status createdAt lastLogin')
            .sort({ createdAt: -1 })
            .lean();

        return res.json({
            success: true,
            data: users,
            count: users.length,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('Error fetching users:', error);
        return res.status(500).json({
            success: false,
            message: 'Error fetching users',
            error: error.message
        });
    }
},

// Updated getStats to include pending users count
getStats: async (req, res) => {
    try {
        // Basic stats
        const [totalUsers, activeUsers, pendingUsers, inactiveUsers, adminUsers] = await Promise.all([
            User.countDocuments(),
            User.countDocuments({ status: 'active' }),
            User.countDocuments({ status: 'pending' }),
            User.countDocuments({ status: 'inactive' }),
            User.countDocuments({ role: 'admin' })
        ]);

        const [totalArticles, hiddenArticles, totalComments] = await Promise.all([
            Article.countDocuments(),
            Article.countDocuments({ hidden: true }),
            Comment.countDocuments()
        ]);

        // ... (keep all existing stats logic) ...

        // Update the users stats section
        const stats = {
            users: {
                total: totalUsers,
                active: activeUsers,
                pending: pendingUsers,  // Add this
                inactive: inactiveUsers,
                admins: adminUsers
            },
            // ... (keep all other existing stats) ...
        };

        res.json({
            success: true,
            data: stats,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('Error fetching admin statistics:', error);
        res.status(500).json({
            success: false,
            message: 'Error fetching statistics',
            error: error.message
        });
    }


// Helper function to calculate storage used
async function calculateStorageUsed() {
    try {
        const articleStorage = await Article.aggregate([
            {
                $group: {
                    _id: null,
                    total: {
                        $sum: { $ifNull: ['$fileSize', 0] }
                    }
                }
            }
        ]);

        return articleStorage[0]?.total || 0;
    } catch (error) {
        console.error('Error calculating storage:', error);
        return 0;
    }
    };
    }
};



module.exports = adminController;
