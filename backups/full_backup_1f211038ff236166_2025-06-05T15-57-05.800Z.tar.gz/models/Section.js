// models/Section.js
const mongoose = require('mongoose');

const sectionSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Section name is required'],
        index: { unique: true, collation: { locale: 'en', strength: 2 } }, // Case-insensitive unique
        trim: true,
        maxLength: [50, 'Section name cannot exceed 50 characters']
    },
    slug: {
        type: String,
        unique: true,
        lowercase: true,
        trim: true
    },
    description: {
        type: String,
        trim: true,
        maxLength: [200, 'Description cannot exceed 200 characters']
    },
    icon: {
        type: String,
        default: 'folder' // Default icon name
    },
    order: {
        type: Number,
        default: 0
    },
    parentSection: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Section',
        default: null
    },
    isActive: {
        type: Boolean,
        default: true
    },
    createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    articleCount: {
        type: Number,
        default: 0
    }
}, { 
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

// Indexes
// sectionSchema.index({ name: 1 });
// sectionSchema.index({ slug: 1 });
sectionSchema.index({ order: 1 });
sectionSchema.index({ parentSection: 1 });

// Generate slug from name
sectionSchema.pre('save', function(next) {
    if (this.isModified('name')) {
        this.slug = this.name
            .toLowerCase()
            .replace(/[^a-z0-9]/g, '-')
            .replace(/-+/g, '-')
            .replace(/^-|-$/g, '');
    }
    next();
});

// Virtual for child sections
sectionSchema.virtual('childSections', {
    ref: 'Section',
    localField: '_id',
    foreignField: 'parentSection'
});

// Virtual for articles in this section
sectionSchema.virtual('articles', {
    ref: 'Article',
    localField: '_id',
    foreignField: 'sections'
});

// Method to update article count
sectionSchema.methods.updateArticleCount = async function() {
    const count = await mongoose.model('Article').countDocuments({
        sections: this._id,
        hidden: false
    });
    this.articleCount = count;
    return this.save();
};

// Static method to get section tree
sectionSchema.statics.getTree = async function() {
    const sections = await this.find({ parentSection: null })
        .populate({
            path: 'childSections',
            populate: { path: 'childSections' }
        });
    return sections;
};

// Method to check if section can be deleted
sectionSchema.methods.canDelete = async function() {
    const articlesCount = await mongoose.model('Article').countDocuments({
        sections: this._id
    });
    const childrenCount = await this.model('Section').countDocuments({
        parentSection: this._id
    });
    return articlesCount === 0 && childrenCount === 0;
};

const Section = mongoose.model('Section', sectionSchema);

module.exports = Section;